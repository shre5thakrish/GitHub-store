import { useState, useEffect } from 'react';
import { Navigation } from '@/components/Navigation';
import { SearchDialog } from '@/components/SearchDialog';
import { RepoDetailModal } from '@/components/RepoDetailModal';
import { HeroSection } from '@/sections/HeroSection';
import { BrowseSection } from '@/sections/BrowseSection';
import { TrendingSection } from '@/sections/TrendingSection';
import { CategoriesSection } from '@/sections/CategoriesSection';
import { ReviewsSection } from '@/sections/ReviewsSection';
import { InstallCTASection } from '@/sections/InstallCTASection';
import { useRealtimeRepos } from '@/hooks/useRealtimeRepos';
import { getMockRepositories } from '@/services/githubApi';

// Create a context for repository selection
import { createContext, useContext } from 'react';

interface RepoContextType {
  selectedRepo: string | null;
  setSelectedRepo: (repo: string | null) => void;
}

const RepoContext = createContext<RepoContextType>({
  selectedRepo: null,
  setSelectedRepo: () => {},
});

export const useRepoContext = () => useContext(RepoContext);

function App() {
  const [searchOpen, setSearchOpen] = useState(false);
  const [selectedRepo, setSelectedRepo] = useState<string | null>(null);
  
  // Initialize real-time updates for featured repos
  const mockRepos = getMockRepositories();
  useRealtimeRepos(mockRepos);

  // Keyboard shortcut for search
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key === 'k') {
        e.preventDefault();
        setSearchOpen(true);
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  // Handle repository click from URL hash
  useEffect(() => {
    const handleHashChange = () => {
      const hash = window.location.hash;
      if (hash.startsWith('#/repo/')) {
        const repoFullName = hash.replace('#/repo/', '');
        setSelectedRepo(repoFullName);
      }
    };

    // Check initial hash
    handleHashChange();

    window.addEventListener('hashchange', handleHashChange);
    return () => window.removeEventListener('hashchange', handleHashChange);
  }, []);

  const handleRepoModalClose = (open: boolean) => {
    if (!open) {
      setSelectedRepo(null);
      // Clear hash without scrolling
      history.pushState('', document.title, window.location.pathname + window.location.search);
    }
  };

  return (
    <RepoContext.Provider value={{ selectedRepo, setSelectedRepo }}>
      <div className="relative min-h-screen bg-white">
        {/* Navigation */}
        <Navigation onSearchClick={() => setSearchOpen(true)} />

        {/* Search Dialog */}
        <SearchDialog open={searchOpen} onOpenChange={setSearchOpen} />

        {/* Repository Detail Modal */}
        <RepoDetailModal
          repoFullName={selectedRepo}
          open={!!selectedRepo}
          onOpenChange={handleRepoModalClose}
        />

        {/* Main Content */}
        <main className="relative">
          <HeroSection onSearchClick={() => setSearchOpen(true)} />
          <BrowseSection />
          <TrendingSection />
          <CategoriesSection />
          <ReviewsSection />
          <InstallCTASection />
        </main>

        {/* Live Update Indicator - Fixed */}
        <div className="fixed bottom-4 right-4 z-40">
          <div className="flex items-center gap-2 px-3 py-2 bg-white border border-slate-200 rounded-full shadow-lg">
            <span className="relative flex h-2 w-2">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-green-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2 w-2 bg-green-500"></span>
            </span>
            <span className="text-xs text-slate-600 font-medium">Live Updates</span>
          </div>
        </div>
      </div>
    </RepoContext.Provider>
  );
}

export default App;
