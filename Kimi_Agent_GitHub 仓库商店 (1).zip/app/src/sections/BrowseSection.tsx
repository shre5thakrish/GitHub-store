import { useEffect, useRef, useState } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { RepositoryCard } from '@/components/cards/RepositoryCard';
import { getFeaturedRepositories, getMockRepositories } from '@/services/githubApi';
import type { Repository } from '@/types/github';
import { Button } from '@/components/ui/button';
import { ChevronLeft, ChevronRight, Sparkles, Activity } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

export function BrowseSection() {
  const sectionRef = useRef<HTMLElement>(null);
  const gridRef = useRef<HTMLDivElement>(null);

  const [featuredRepos, setFeaturedRepos] = useState<Repository[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [currentPage, setCurrentPage] = useState(0);
  const reposPerPage = 6;

  useEffect(() => {
    const loadFeatured = async () => {
      setIsLoading(true);
      const repos = await getFeaturedRepositories();
      if (repos.length === 0) {
        setFeaturedRepos(getMockRepositories());
      } else {
        setFeaturedRepos(repos);
      }
      setIsLoading(false);
    };
    loadFeatured();
  }, []);

  useEffect(() => {
    const section = sectionRef.current;
    if (!section) return;

    const ctx = gsap.context(() => {
      const gridItems = gridRef.current?.children;
      if (gridItems) {
        gsap.fromTo(
          gridItems,
          { opacity: 0, y: 20 },
          {
            opacity: 1,
            y: 0,
            stagger: 0.05,
            duration: 0.4,
            ease: 'power2.out',
            scrollTrigger: {
              trigger: gridRef.current,
              start: 'top 85%',
              toggleActions: 'play none none reverse',
            },
          }
        );
      }
    }, section);

    return () => ctx.revert();
  }, []);

  const totalPages = Math.ceil(featuredRepos.length / reposPerPage);
  const currentRepos = featuredRepos.slice(
    currentPage * reposPerPage,
    (currentPage + 1) * reposPerPage
  );

  return (
    <section
      ref={sectionRef}
      id="browse"
      className="relative py-16 sm:py-20 bg-white"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 mb-6">
          <div>
            <div className="flex items-center gap-2 mb-2">
              <Sparkles className="w-5 h-5 text-amber-500" />
              <span className="text-sm text-amber-600 font-medium">Featured</span>
            </div>
            <h2 className="text-2xl sm:text-3xl font-bold text-slate-900 mb-2">
              Popular Repositories
            </h2>
            <p className="text-slate-600 text-sm sm:text-base">
              Hand-picked popular projects with live updates
            </p>
          </div>

          {/* Pagination */}
          {totalPages > 1 && (
            <div className="flex items-center gap-2">
              <Button
                variant="outline"
                size="icon"
                className="border-slate-200 text-slate-600 hover:text-slate-900 hover:bg-slate-50 h-10 w-10"
                onClick={() => setCurrentPage((p) => Math.max(0, p - 1))}
                disabled={currentPage === 0}
              >
                <ChevronLeft className="w-4 h-4" />
              </Button>
              <span className="text-sm text-slate-600 min-w-[3rem] text-center">
                {currentPage + 1} / {totalPages}
              </span>
              <Button
                variant="outline"
                size="icon"
                className="border-slate-200 text-slate-600 hover:text-slate-900 hover:bg-slate-50 h-10 w-10"
                onClick={() => setCurrentPage((p) => Math.min(totalPages - 1, p + 1))}
                disabled={currentPage === totalPages - 1}
              >
                <ChevronRight className="w-4 h-4" />
              </Button>
            </div>
          )}
        </div>

        {/* Live Updates Info */}
        <div className="flex items-start gap-3 p-4 bg-gradient-to-r from-green-50 to-blue-50 border border-green-100 rounded-xl mb-6">
          <Activity className="w-5 h-5 text-green-600 flex-shrink-0 mt-0.5" />
          <div>
            <p className="text-sm font-medium text-slate-900 mb-1">
              📊 Real-Time Updates Active
            </p>
            <p className="text-sm text-slate-600">
              These repositories update automatically every 30 seconds. Watch stars, forks, 
              and activity change live! Green numbers indicate new activity.
            </p>
          </div>
        </div>

        {/* Repository Grid */}
        {isLoading ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {[...Array(6)].map((_, i) => (
              <div
                key={i}
                className="p-5 bg-slate-50 border border-slate-100 rounded-xl animate-pulse"
              >
                <div className="flex items-center gap-3 mb-4">
                  <div className="w-10 h-10 rounded-lg bg-slate-200" />
                  <div className="flex-1">
                    <div className="h-4 w-24 bg-slate-200 rounded mb-2" />
                    <div className="h-3 w-16 bg-slate-200 rounded" />
                  </div>
                </div>
                <div className="h-3 w-full bg-slate-200 rounded mb-2" />
                <div className="h-3 w-3/4 bg-slate-200 rounded" />
              </div>
            ))}
          </div>
        ) : (
          <div ref={gridRef} className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {currentRepos.map((repo) => (
              <RepositoryCard key={repo.id} repo={repo} enableRealtime />
            ))}
          </div>
        )}

        {/* View All Button */}
        <div className="flex justify-center mt-8">
          <Button
            variant="outline"
            className="border-slate-200 text-slate-700 hover:bg-slate-50 hover:border-blue-300"
            onClick={() => alert('More repositories coming soon!')}
          >
            View All Repositories
          </Button>
        </div>
      </div>
    </section>
  );
}
