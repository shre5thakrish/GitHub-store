import { useEffect, useRef, useState } from 'react';
import { Search, Sparkles, TrendingUp, BookOpen, Activity, Zap, Wifi } from 'lucide-react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { Input } from '@/components/ui/input';
import { RepositoryCard } from '@/components/cards/RepositoryCard';
import { getFeaturedRepositories, getMockRepositories } from '@/services/githubApi';
import type { Repository } from '@/types/github';
import { useAuth } from '@/hooks/useAuth';

gsap.registerPlugin(ScrollTrigger);

const categories = [
  { name: 'All', icon: Sparkles },
  { name: 'Web', icon: BookOpen },
  { name: 'Mobile', icon: BookOpen },
  { name: 'AI/ML', icon: BookOpen },
  { name: 'Tools', icon: BookOpen },
];

interface HeroSectionProps {
  onSearchClick?: () => void;
}

export function HeroSection({ onSearchClick }: HeroSectionProps) {
  const sectionRef = useRef<HTMLElement>(null);
  const contentRef = useRef<HTMLDivElement>(null);

  const [featuredRepo, setFeaturedRepo] = useState<Repository | null>(null);
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [isLoading, setIsLoading] = useState(true);
  const { isAuthenticated, user } = useAuth();

  useEffect(() => {
    const loadFeatured = async () => {
      setIsLoading(true);
      const repos = await getFeaturedRepositories();
      if (repos.length > 0) {
        setFeaturedRepo(repos[repos.length - 1]);
      } else {
        const mockRepos = getMockRepositories();
        setFeaturedRepo(mockRepos[mockRepos.length - 1]);
      }
      setIsLoading(false);
    };
    loadFeatured();
  }, []);

  useEffect(() => {
    const section = sectionRef.current;
    if (!section) return;

    const ctx = gsap.context(() => {
      gsap.fromTo(
        contentRef.current,
        { opacity: 0, y: 20 },
        {
          opacity: 1,
          y: 0,
          duration: 0.6,
          ease: 'power2.out',
        }
      );
    }, section);

    return () => ctx.revert();
  }, []);

  return (
    <section
      ref={sectionRef}
      className="relative min-h-screen w-full flex flex-col items-center justify-center overflow-hidden bg-gradient-to-b from-blue-50/50 via-white to-white"
    >
      {/* Subtle background decoration */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-20 left-10 w-64 h-64 bg-blue-100/30 rounded-full blur-3xl" />
        <div className="absolute bottom-20 right-10 w-96 h-96 bg-indigo-100/20 rounded-full blur-3xl" />
      </div>

      {/* Content */}
      <div ref={contentRef} className="relative z-10 w-full max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 pt-24 pb-12">
        {/* Welcome Badge */}
        <div className="flex justify-center mb-6">
          <div className="inline-flex items-center gap-2 px-4 py-2 bg-blue-100 text-blue-700 rounded-full text-sm font-medium">
            <Wifi className="w-4 h-4" />
            <span>Live Updates Enabled</span>
            <span className="relative flex h-2 w-2">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-green-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2 w-2 bg-green-500"></span>
            </span>
          </div>
        </div>

        {/* Headline */}
        <h1 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-center text-slate-900 mb-4 leading-tight">
          Discover Amazing
          <span className="text-gradient"> GitHub Repositories</span>
        </h1>

        {/* Subheadline - Beginner friendly */}
        <p className="text-base sm:text-lg text-center text-slate-600 mb-8 max-w-2xl mx-auto leading-relaxed">
          Find the best open-source projects with <span className="font-semibold text-blue-600">real-time updates</span>. 
          Watch stars, forks, and activity change live as you browse.
        </p>

        {/* Search Card */}
        <div className="w-full max-w-2xl mx-auto bg-white border border-slate-200 rounded-2xl p-4 sm:p-6 shadow-lg mb-8">
          {/* Search Input */}
          <div 
            className="relative mb-4 cursor-pointer"
            onClick={onSearchClick}
          >
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
            <Input
              placeholder="Search for React, Python, AI tools..."
              className="w-full h-12 sm:h-14 pl-12 pr-4 bg-slate-50 border-slate-200 rounded-xl text-slate-900 placeholder:text-slate-400 text-base cursor-pointer hover:bg-slate-100 transition-colors"
              readOnly
            />
            <div className="absolute right-3 top-1/2 -translate-y-1/2 hidden sm:flex items-center gap-1">
              <kbd className="px-2 py-1 text-xs font-mono text-slate-400 bg-white border border-slate-200 rounded">
                ⌘K
              </kbd>
            </div>
          </div>

          {/* Quick Tips */}
          <div className="flex flex-wrap items-center justify-center gap-2 text-xs text-slate-500 mb-4">
            <span>Try:</span>
            <button onClick={onSearchClick} className="px-2 py-1 bg-slate-100 hover:bg-blue-100 hover:text-blue-600 rounded transition-colors">react</button>
            <button onClick={onSearchClick} className="px-2 py-1 bg-slate-100 hover:bg-blue-100 hover:text-blue-600 rounded transition-colors">nextjs</button>
            <button onClick={onSearchClick} className="px-2 py-1 bg-slate-100 hover:bg-blue-100 hover:text-blue-600 rounded transition-colors">tailwind</button>
            <button onClick={onSearchClick} className="px-2 py-1 bg-slate-100 hover:bg-blue-100 hover:text-blue-600 rounded transition-colors">ai</button>
          </div>

          {/* Category Pills */}
          <div className="flex flex-wrap justify-center gap-2">
            {categories.map((cat) => (
              <button
                key={cat.name}
                onClick={() => setSelectedCategory(cat.name)}
                className={`px-4 py-2 rounded-full text-sm font-medium transition-all duration-200 ${
                  selectedCategory === cat.name
                    ? 'bg-blue-600 text-white shadow-md'
                    : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                }`}
              >
                {cat.name}
              </button>
            ))}
          </div>
        </div>

        {/* Live Features Row */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 sm:gap-4 mb-8">
          <div className="flex items-center gap-3 p-3 bg-white border border-slate-200 rounded-xl">
            <div className="w-10 h-10 rounded-xl bg-green-100 flex items-center justify-center flex-shrink-0">
              <Activity className="w-5 h-5 text-green-600" />
            </div>
            <div>
              <p className="text-sm font-semibold text-slate-900">Live Stats</p>
              <p className="text-xs text-slate-500">Updates every 30s</p>
            </div>
          </div>
          <div className="flex items-center gap-3 p-3 bg-white border border-slate-200 rounded-xl">
            <div className="w-10 h-10 rounded-xl bg-amber-100 flex items-center justify-center flex-shrink-0">
              <TrendingUp className="w-5 h-5 text-amber-600" />
            </div>
            <div>
              <p className="text-sm font-semibold text-slate-900">10K+</p>
              <p className="text-xs text-slate-500">Repositories</p>
            </div>
          </div>
          <div className="flex items-center gap-3 p-3 bg-white border border-slate-200 rounded-xl">
            <div className="w-10 h-10 rounded-xl bg-blue-100 flex items-center justify-center flex-shrink-0">
              <Zap className="w-5 h-5 text-blue-600" />
            </div>
            <div>
              <p className="text-sm font-semibold text-slate-900">Real-time</p>
              <p className="text-xs text-slate-500">Data from GitHub</p>
            </div>
          </div>
          <div className="flex items-center gap-3 p-3 bg-white border border-slate-200 rounded-xl">
            <div className="w-10 h-10 rounded-xl bg-purple-100 flex items-center justify-center flex-shrink-0">
              <Sparkles className="w-5 h-5 text-purple-600" />
            </div>
            <div>
              <p className="text-sm font-semibold text-slate-900">Free</p>
              <p className="text-xs text-slate-500">Forever</p>
            </div>
          </div>
        </div>

        {/* GitHub Login CTA */}
        {!isAuthenticated && (
          <div className="p-4 bg-gradient-to-r from-slate-900 to-slate-800 rounded-xl mb-8">
            <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
              <div className="text-center sm:text-left">
                <p className="text-white font-medium">Connect your GitHub account</p>
                <p className="text-slate-400 text-sm">See your repos, stars, and get personalized recommendations</p>
              </div>
              <button 
                onClick={() => alert('GitHub OAuth would open here!\n\nIn production, this would:\n1. Open GitHub OAuth flow\n2. Request user permissions\n3. Fetch your profile and repos\n4. Show personalized content')}
                className="px-4 py-2 bg-white text-slate-900 rounded-lg font-medium hover:bg-slate-100 transition-colors flex items-center gap-2"
              >
                <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M12 0c-6.626 0-12 5.373-12 12 0 5.302 3.438 9.8 8.207 11.387.599.111.793-.261.793-.577v-2.234c-3.338.726-4.033-1.416-4.033-1.416-.546-1.387-1.333-1.756-1.333-1.756-1.089-.745.083-.729.083-.729 1.205.084 1.839 1.237 1.839 1.237 1.07 1.834 2.807 1.304 3.492.997.107-.775.418-1.305.762-1.604-2.665-.305-5.467-1.334-5.467-5.931 0-1.311.469-2.381 1.236-3.221-.124-.303-.535-1.524.117-3.176 0 0 1.008-.322 3.301 1.23.957-.266 1.983-.399 3.003-.404 1.02.005 2.047.138 3.006.404 2.291-1.552 3.297-1.23 3.297-1.23.653 1.653.242 2.874.118 3.176.77.84 1.235 1.911 1.235 3.221 0 4.609-2.807 5.624-5.479 5.921.43.372.823 1.102.823 2.222v3.293c0 .319.192.694.801.576 4.765-1.589 8.199-6.086 8.199-11.386 0-6.627-5.373-12-12-12z"/>
                </svg>
                Sign in with GitHub
              </button>
            </div>
          </div>
        )}

        {/* User Welcome (when logged in) */}
        {isAuthenticated && user && (
          <div className="p-4 bg-blue-50 border border-blue-200 rounded-xl mb-8">
            <div className="flex items-center gap-3">
              <img 
                src={user.avatar_url} 
                alt={user.name || user.login}
                className="w-12 h-12 rounded-full"
              />
              <div>
                <p className="font-medium text-slate-900">Welcome back, {user.name || user.login}!</p>
                <p className="text-sm text-slate-600">
                  You have {user.public_repos} public repositories • {user.followers} followers
                </p>
              </div>
            </div>
          </div>
        )}

        {/* Featured Repo */}
        {featuredRepo && !isLoading && (
          <div className="max-w-lg mx-auto">
            <div className="flex items-center gap-2 mb-3 justify-center">
              <Sparkles className="w-4 h-4 text-amber-500" />
              <span className="text-sm text-slate-500 font-medium">Featured Repository (with Live Updates)</span>
            </div>
            <RepositoryCard repo={featuredRepo} variant="compact" enableRealtime />
          </div>
        )}

        {/* Scroll Hint */}
        <div className="flex justify-center mt-10">
          <a 
            href="#browse" 
            className="flex flex-col items-center gap-1 text-slate-400 hover:text-blue-600 transition-colors"
          >
            <span className="text-xs">Scroll to explore</span>
            <svg className="w-5 h-5 animate-bounce" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 14l-7 7m0 0l-7-7m7 7V3" />
            </svg>
          </a>
        </div>
      </div>
    </section>
  );
}
