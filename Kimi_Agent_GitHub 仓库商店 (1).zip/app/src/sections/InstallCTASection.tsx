import { useState } from 'react';
import { Copy, Check, ArrowUp, Heart, Github } from 'lucide-react';
import { Button } from '@/components/ui/button';

export function InstallCTASection() {
  const [copied, setCopied] = useState(false);
  const installCommand = 'npx create-react-app my-app';

  const handleCopy = () => {
    navigator.clipboard.writeText(installCommand);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <section className="relative py-16 sm:py-20 bg-gradient-to-b from-white to-slate-50">
      <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
        {/* Icon */}
        <div className="w-16 h-16 bg-blue-100 rounded-2xl flex items-center justify-center mx-auto mb-6">
          <Github className="w-8 h-8 text-blue-600" />
        </div>

        {/* Headline */}
        <h2 className="text-2xl sm:text-3xl font-bold text-slate-900 mb-4">
          Ready to start building?
        </h2>
        <p className="text-slate-600 mb-8 max-w-lg mx-auto">
          Explore thousands of open-source repositories and find the perfect tools for your next project.
        </p>

        {/* Quick Start */}
        <div className="bg-white border border-slate-200 rounded-2xl p-5 sm:p-6 shadow-sm mb-8">
          <p className="text-sm text-slate-500 mb-3">Quick start command</p>
          <div className="flex items-center gap-2">
            <code className="flex-1 p-3 bg-slate-50 border border-slate-200 rounded-lg text-sm text-slate-700 font-mono text-left overflow-x-auto">
              {installCommand}
            </code>
            <Button
              onClick={handleCopy}
              variant="outline"
              size="icon"
              className={`h-11 w-11 border-slate-200 flex-shrink-0 ${
                copied ? 'border-green-300 bg-green-50' : ''
              }`}
            >
              {copied ? <Check className="w-4 h-4 text-green-600" /> : <Copy className="w-4 h-4" />}
            </Button>
          </div>
          <p className="text-xs text-slate-400 mt-2 text-left">
            Copy and paste this in your terminal to get started
          </p>
        </div>

        {/* Action Buttons */}
        <div className="flex flex-col sm:flex-row items-center justify-center gap-3 mb-10">
          <Button 
            className="w-full sm:w-auto bg-blue-600 hover:bg-blue-700 text-white"
            onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
          >
            Start Exploring
          </Button>
          <Button 
            variant="outline" 
            className="w-full sm:w-auto border-slate-200 text-slate-700 hover:bg-slate-50"
            onClick={() => alert('Documentation coming soon!')}
          >
            Read Documentation
          </Button>
        </div>

        {/* Made with love */}
        <div className="flex items-center justify-center gap-2 text-slate-500 text-sm mb-8">
          <span>Made with</span>
          <Heart className="w-4 h-4 text-red-500 fill-red-500" />
          <span>for the open-source community</span>
        </div>
      </div>

      {/* Footer */}
      <footer className="border-t border-slate-200 mt-10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
            <div className="flex items-center gap-4 text-sm text-slate-500">
              <a href="#" className="hover:text-blue-600 transition-colors">Privacy</a>
              <a href="#" className="hover:text-blue-600 transition-colors">Terms</a>
              <a href="#" className="hover:text-blue-600 transition-colors">Contact</a>
            </div>

            <button
              onClick={scrollToTop}
              className="flex items-center gap-2 text-sm text-slate-500 hover:text-blue-600 transition-colors"
            >
              <span>Back to top</span>
              <ArrowUp className="w-4 h-4" />
            </button>
          </div>
        </div>
      </footer>
    </section>
  );
}
