import { useEffect, useRef, useState } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { CategoryCard, CategoryPill } from '@/components/cards/CategoryCard';
import { RepositoryCard } from '@/components/cards/RepositoryCard';
import { categories } from '@/data/categories';
import { getRepositoriesByTopic, getMockRepositories } from '@/services/githubApi';
import type { Repository } from '@/types/github';
import { ArrowLeft, Info, FolderOpen } from 'lucide-react';
import { Button } from '@/components/ui/button';

gsap.registerPlugin(ScrollTrigger);

export function CategoriesSection() {
  const sectionRef = useRef<HTMLElement>(null);
  const gridRef = useRef<HTMLDivElement>(null);

  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [repos, setRepos] = useState<Repository[]>([]);
  const [isLoading, setIsLoading] = useState(false);

  useEffect(() => {
    const loadRepos = async () => {
      setIsLoading(true);
      if (selectedCategory) {
        const category = categories.find((c) => c.id === selectedCategory);
        if (category) {
          const fetchedRepos = await getRepositoriesByTopic(category.topic, 9);
          if (fetchedRepos.length === 0) {
            const mockRepos = getMockRepositories().filter(
              (r) =>
                r.topics.some((t) => t.toLowerCase().includes(category.topic.toLowerCase())) ||
                r.description?.toLowerCase().includes(category.name.toLowerCase())
            );
            setRepos(mockRepos.length > 0 ? mockRepos : getMockRepositories().slice(0, 6));
          } else {
            setRepos(fetchedRepos);
          }
        }
      } else {
        setRepos([]);
      }
      setIsLoading(false);
    };
    loadRepos();
  }, [selectedCategory]);

  useEffect(() => {
    const section = sectionRef.current;
    if (!section) return;

    const ctx = gsap.context(() => {
      const gridItems = gridRef.current?.children;
      if (gridItems) {
        gsap.fromTo(
          gridItems,
          { opacity: 0, y: 20 },
          {
            opacity: 1,
            y: 0,
            stagger: 0.05,
            duration: 0.4,
            ease: 'power2.out',
            scrollTrigger: {
              trigger: gridRef.current,
              start: 'top 85%',
              toggleActions: 'play none none reverse',
            },
          }
        );
      }
    }, section);

    return () => ctx.revert();
  }, []);

  return (
    <section
      ref={sectionRef}
      id="categories"
      className="relative py-16 sm:py-20 bg-white"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="mb-6">
          <div className="flex items-center gap-2 mb-2">
            <FolderOpen className="w-5 h-5 text-green-600" />
            <span className="text-sm text-green-600 font-medium">Browse by Topic</span>
          </div>
          <h2 className="text-2xl sm:text-3xl font-bold text-slate-900 mb-2">
            Categories
          </h2>
          <p className="text-slate-600 text-sm sm:text-base">
            Find repositories built for your specific needs
          </p>
        </div>

        {/* Help Tip */}
        {!selectedCategory && (
          <div className="flex items-start gap-2 p-3 bg-green-50 rounded-lg mb-6">
            <Info className="w-4 h-4 text-green-600 flex-shrink-0 mt-0.5" />
            <p className="text-sm text-green-700">
              Select a category below to see repositories related to that topic. 
              Not sure? Start with &quot;Web Development&quot; for frontend projects!
            </p>
          </div>
        )}

        {/* Category Pills */}
        <div className="flex flex-wrap gap-2 mb-8">
          {categories.map((category) => (
            <CategoryPill
              key={category.id}
              category={category}
              isSelected={selectedCategory === category.id}
              onClick={() =>
                setSelectedCategory(selectedCategory === category.id ? null : category.id)
              }
            />
          ))}
        </div>

        {/* Category Cards Grid */}
        {!selectedCategory && (
          <div ref={gridRef} className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {categories.map((category) => (
              <CategoryCard
                key={category.id}
                category={category}
                onClick={() => setSelectedCategory(category.id)}
              />
            ))}
          </div>
        )}

        {/* Repository Grid for Selected Category */}
        {selectedCategory && (
          <div>
            <div className="flex items-center justify-between mb-6">
              <div>
                <h3 className="text-xl font-semibold text-slate-900">
                  {categories.find((c) => c.id === selectedCategory)?.name}
                </h3>
                <p className="text-sm text-slate-500 mt-1">
                  Showing repositories in this category
                </p>
              </div>
              <Button
                variant="outline"
                size="sm"
                className="border-slate-200 text-slate-700 hover:bg-slate-50"
                onClick={() => setSelectedCategory(null)}
              >
                <ArrowLeft className="w-4 h-4 mr-2" />
                Back
              </Button>
            </div>

            {isLoading ? (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                {[...Array(6)].map((_, i) => (
                  <div
                    key={i}
                    className="p-5 bg-slate-50 border border-slate-100 rounded-xl animate-pulse"
                  >
                    <div className="flex items-center gap-3 mb-4">
                      <div className="w-10 h-10 rounded-xl bg-slate-200" />
                      <div className="flex-1">
                        <div className="h-4 w-24 bg-slate-200 rounded mb-2" />
                        <div className="h-3 w-16 bg-slate-200 rounded" />
                      </div>
                    </div>
                    <div className="h-3 w-full bg-slate-200 rounded mb-2" />
                    <div className="h-3 w-3/4 bg-slate-200 rounded" />
                  </div>
                ))}
              </div>
            ) : repos.length > 0 ? (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                {repos.map((repo) => (
                  <RepositoryCard key={repo.id} repo={repo} />
                ))}
              </div>
            ) : (
              <div className="text-center py-12 bg-slate-50 rounded-xl">
                <FolderOpen className="w-12 h-12 text-slate-300 mx-auto mb-3" />
                <p className="text-slate-600 font-medium">No repositories found</p>
                <p className="text-sm text-slate-500 mt-1">Try selecting a different category</p>
              </div>
            )}
          </div>
        )}
      </div>
    </section>
  );
}
