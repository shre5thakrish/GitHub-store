import { useEffect, useRef, useState } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { TrendingCard } from '@/components/cards/TrendingCard';
import { getTrendingRepositories, getMockRepositories } from '@/services/githubApi';
import type { Repository, TimeRange } from '@/types/github';
import { Info, TrendingUp } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

const timeRanges: { value: TimeRange; label: string; description: string }[] = [
  { value: 'daily', label: 'Today', description: 'Trending in the last 24 hours' },
  { value: 'weekly', label: 'This Week', description: 'Trending in the last 7 days' },
  { value: 'monthly', label: 'This Month', description: 'Trending in the last 30 days' },
];

export function TrendingSection() {
  const sectionRef = useRef<HTMLElement>(null);
  const scrollContainerRef = useRef<HTMLDivElement>(null);

  const [selectedRange, setSelectedRange] = useState<TimeRange>('weekly');
  const [trendingRepos, setTrendingRepos] = useState<Repository[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const loadTrending = async () => {
      setIsLoading(true);
      const repos = await getTrendingRepositories(selectedRange, undefined, 10);
      if (repos.length === 0) {
        setTrendingRepos(getMockRepositories().slice(0, 6));
      } else {
        setTrendingRepos(repos);
      }
      setIsLoading(false);
    };
    loadTrending();
  }, [selectedRange]);

  useEffect(() => {
    const section = sectionRef.current;
    if (!section) return;

    const ctx = gsap.context(() => {
      const cards = scrollContainerRef.current?.children;
      if (cards) {
        gsap.fromTo(
          cards,
          { opacity: 0, y: 20 },
          {
            opacity: 1,
            y: 0,
            stagger: 0.05,
            duration: 0.4,
            ease: 'power2.out',
            scrollTrigger: {
              trigger: scrollContainerRef.current,
              start: 'top 85%',
              toggleActions: 'play none none reverse',
            },
          }
        );
      }
    }, section);

    return () => ctx.revert();
  }, []);

  const currentRange = timeRanges.find(r => r.value === selectedRange);

  return (
    <section
      ref={sectionRef}
      id="trending"
      className="relative py-16 sm:py-20 bg-slate-50"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 mb-6">
          <div>
            <div className="flex items-center gap-2 mb-2">
              <TrendingUp className="w-5 h-5 text-blue-600" />
              <span className="text-sm text-blue-600 font-medium">Trending Now</span>
            </div>
            <h2 className="text-2xl sm:text-3xl font-bold text-slate-900 mb-2">
              What&apos;s Hot
            </h2>
            <p className="text-slate-600 text-sm sm:text-base">
              {currentRange?.description}
            </p>
          </div>

          {/* Time Range Tabs */}
          <div className="flex items-center gap-1 bg-white p-1 rounded-xl border border-slate-200">
            {timeRanges.map((range) => (
              <button
                key={range.value}
                onClick={() => setSelectedRange(range.value)}
                className={`px-3 sm:px-4 py-2 rounded-lg text-sm font-medium transition-all duration-200 ${
                  selectedRange === range.value
                    ? 'bg-blue-600 text-white shadow-sm'
                    : 'text-slate-600 hover:bg-slate-100'
                }`}
              >
                {range.label}
              </button>
            ))}
          </div>
        </div>

        {/* Help Tip */}
        <div className="flex items-start gap-2 p-3 bg-blue-50 rounded-lg mb-6">
          <Info className="w-4 h-4 text-blue-600 flex-shrink-0 mt-0.5" />
          <p className="text-sm text-blue-700">
            These repositories are gaining popularity fast. Check them out before everyone else does!
          </p>
        </div>

        {/* Horizontal Scroll Container */}
        <div
          ref={scrollContainerRef}
          className="flex gap-4 overflow-x-auto pb-4 scrollbar-hide snap-x snap-mandatory -mx-4 px-4 sm:mx-0 sm:px-0"
        >
          {isLoading ? (
            [...Array(5)].map((_, i) => (
              <div
                key={i}
                className="w-[260px] sm:w-[280px] flex-shrink-0 p-5 bg-white border border-slate-200 rounded-xl animate-pulse snap-start"
              >
                <div className="flex items-center gap-3 mb-4">
                  <div className="w-12 h-12 rounded-xl bg-slate-100" />
                  <div className="flex-1">
                    <div className="h-4 w-24 bg-slate-100 rounded mb-2" />
                    <div className="h-3 w-16 bg-slate-100 rounded" />
                  </div>
                </div>
                <div className="h-3 w-full bg-slate-100 rounded mb-2" />
                <div className="h-3 w-3/4 bg-slate-100 rounded" />
              </div>
            ))
          ) : (
            trendingRepos.map((repo, index) => (
              <TrendingCard
                key={repo.id}
                repo={repo}
                rank={index + 1}
                trendingStars={Math.floor(Math.random() * 500) + 50}
              />
            ))
          )}
        </div>

        {/* Scroll Hint - Mobile only */}
        <div className="flex items-center justify-center mt-4 text-slate-500 text-sm sm:hidden">
          <span>Swipe to see more</span>
          <svg
            className="w-4 h-4 ml-2 animate-pulse"
            fill="none"
            viewBox="0 0 24 24"
            stroke="currentColor"
          >
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
          </svg>
        </div>
      </div>
    </section>
  );
}
