import { useEffect, useRef } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { ReviewCard, RatingSummary } from '@/components/cards/ReviewCard';
import { mockReviews, getAverageRating, getRatingDistribution } from '@/data/reviews';
import { MessageSquare, Info } from 'lucide-react';
import { Button } from '@/components/ui/button';

gsap.registerPlugin(ScrollTrigger);

export function ReviewsSection() {
  const sectionRef = useRef<HTMLElement>(null);
  const summaryRef = useRef<HTMLDivElement>(null);
  const reviewsRef = useRef<HTMLDivElement>(null);

  const averageRating = getAverageRating(mockReviews);
  const distribution = getRatingDistribution(mockReviews);

  useEffect(() => {
    const section = sectionRef.current;
    if (!section) return;

    const ctx = gsap.context(() => {
      gsap.fromTo(
        summaryRef.current,
        { opacity: 0, y: 20 },
        {
          opacity: 1,
          y: 0,
          duration: 0.4,
          ease: 'power2.out',
          scrollTrigger: {
            trigger: section,
            start: 'top 85%',
            toggleActions: 'play none none reverse',
          },
        }
      );

      const reviewCards = reviewsRef.current?.children;
      if (reviewCards) {
        gsap.fromTo(
          reviewCards,
          { opacity: 0, y: 20 },
          {
            opacity: 1,
            y: 0,
            stagger: 0.05,
            duration: 0.4,
            ease: 'power2.out',
            scrollTrigger: {
              trigger: reviewsRef.current,
              start: 'top 85%',
              toggleActions: 'play none none reverse',
            },
          }
        );
      }
    }, section);

    return () => ctx.revert();
  }, []);

  return (
    <section
      ref={sectionRef}
      id="reviews"
      className="relative py-16 sm:py-20 bg-slate-50"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center gap-2 mb-2">
            <MessageSquare className="w-5 h-5 text-purple-600" />
            <span className="text-sm text-purple-600 font-medium">Community</span>
          </div>
          <h2 className="text-2xl sm:text-3xl font-bold text-slate-900 mb-2">
            What Developers Say
          </h2>
          <p className="text-slate-600 text-sm sm:text-base">
            Reviews from the community about these repositories
          </p>
        </div>

        {/* Help Tip */}
        <div className="flex items-start gap-2 p-3 bg-purple-50 rounded-lg mb-6">
          <Info className="w-4 h-4 text-purple-600 flex-shrink-0 mt-0.5" />
          <p className="text-sm text-purple-700">
            These reviews help you understand what other developers think about these projects before you use them.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Rating Summary */}
          <div ref={summaryRef} className="lg:col-span-1">
            <RatingSummary
              rating={averageRating}
              reviewCount={mockReviews.length}
              distribution={distribution}
            />
          </div>

          {/* Review Cards */}
          <div ref={reviewsRef} className="lg:col-span-2 grid grid-cols-1 sm:grid-cols-2 gap-4">
            {mockReviews.slice(0, 4).map((review) => (
              <ReviewCard key={review.id} review={review} />
            ))}
          </div>
        </div>

        {/* Write Review CTA */}
        <div className="mt-8 text-center p-6 bg-white rounded-xl border border-slate-200">
          <p className="text-slate-600 mb-4">
            Have you used any of these repositories? Share your experience with the community!
          </p>
          <Button 
            className="bg-blue-600 hover:bg-blue-700 text-white"
            onClick={() => alert('Review feature coming soon!')}
          >
            <MessageSquare className="w-4 h-4 mr-2" />
            Write a Review
          </Button>
        </div>
      </div>
    </section>
  );
}
