import { useState, useEffect, useCallback } from 'react';
import type { Repository } from '@/types/github';

interface RepoStats {
  stargazers_count: number;
  forks_count: number;
  watchers_count: number;
  open_issues_count: number;
  updated_at: string;
}

interface RealtimeRepo extends Repository {
  lastUpdated: Date;
  isUpdating: boolean;
}

// Store for real-time repository data
class RealtimeRepoStore {
  private repos: Map<number, RealtimeRepo> = new Map();
  private listeners: Set<(repos: Map<number, RealtimeRepo>) => void> = new Set();
  private intervals: Map<number, ReturnType<typeof setInterval>> = new Map();

  subscribe(listener: (repos: Map<number, RealtimeRepo>) => void) {
    this.listeners.add(listener);
    return () => this.listeners.delete(listener);
  }

  private notify() {
    this.listeners.forEach((listener) => listener(new Map(this.repos)));
  }

  addRepo(repo: Repository) {
    if (!this.repos.has(repo.id)) {
      this.repos.set(repo.id, {
        ...repo,
        lastUpdated: new Date(),
        isUpdating: false,
      });
      this.startPolling(repo.id);
      this.notify();
    }
  }

  removeRepo(repoId: number) {
    this.stopPolling(repoId);
    this.repos.delete(repoId);
    this.notify();
  }

  updateRepo(repoId: number, updates: Partial<RepoStats>) {
    const repo = this.repos.get(repoId);
    if (repo) {
      this.repos.set(repoId, {
        ...repo,
        ...updates,
        lastUpdated: new Date(),
        isUpdating: false,
      });
      this.notify();
    }
  }

  setUpdating(repoId: number, isUpdating: boolean) {
    const repo = this.repos.get(repoId);
    if (repo) {
      this.repos.set(repoId, { ...repo, isUpdating });
      this.notify();
    }
  }

  private startPolling(repoId: number) {
    // Poll every 30 seconds for updates
    const interval = setInterval(() => {
      this.pollRepo(repoId);
    }, 30000);
    this.intervals.set(repoId, interval);
  }

  private stopPolling(repoId: number) {
    const interval = this.intervals.get(repoId);
    if (interval) {
      clearInterval(interval);
      this.intervals.delete(repoId);
    }
  }

  private async pollRepo(repoId: number) {
    const repo = this.repos.get(repoId);
    if (!repo) return;

    this.setUpdating(repoId, true);

    try {
      const [owner, repoName] = repo.full_name.split('/');
      const response = await fetch(`https://api.github.com/repos/${owner}/${repoName}`, {
        headers: {
          'Accept': 'application/vnd.github.v3+json',
        },
      });

      if (response.ok) {
        const data = await response.json();
        
        // Check if there are actual changes
        const hasChanges = 
          data.stargazers_count !== repo.stargazers_count ||
          data.forks_count !== repo.forks_count ||
          data.watchers_count !== repo.watchers_count ||
          data.open_issues_count !== repo.open_issues_count;

        if (hasChanges) {
          this.updateRepo(repoId, {
            stargazers_count: data.stargazers_count,
            forks_count: data.forks_count,
            watchers_count: data.watchers_count,
            open_issues_count: data.open_issues_count,
            updated_at: data.updated_at,
          });
        }
      }
    } catch (error) {
      console.error('Error polling repo:', error);
    } finally {
      this.setUpdating(repoId, false);
    }
  }

  getRepo(repoId: number): RealtimeRepo | undefined {
    return this.repos.get(repoId);
  }

  getAllRepos(): RealtimeRepo[] {
    return Array.from(this.repos.values());
  }

  clear() {
    this.intervals.forEach((interval) => clearInterval(interval));
    this.intervals.clear();
    this.repos.clear();
    this.notify();
  }
}

// Singleton instance
const realtimeStore = new RealtimeRepoStore();

// Hook for using real-time repository updates
export const useRealtimeRepos = (repos?: Repository[]) => {
  const [realtimeRepos, setRealtimeRepos] = useState<Map<number, RealtimeRepo>>(new Map());

  useEffect(() => {
    // Subscribe to store changes
    const unsubscribe = realtimeStore.subscribe(setRealtimeRepos);

    // Add initial repos
    if (repos) {
      repos.forEach((repo) => realtimeStore.addRepo(repo));
    }

    return () => {
      unsubscribe();
    };
  }, [repos]);

  const addRepo = useCallback((repo: Repository) => {
    realtimeStore.addRepo(repo);
  }, []);

  const removeRepo = useCallback((repoId: number) => {
    realtimeStore.removeRepo(repoId);
  }, []);

  const refreshRepo = useCallback(async (repoId: number) => {
    const repo = realtimeStore.getRepo(repoId);
    if (!repo) return;

    realtimeStore.setUpdating(repoId, true);

    try {
      const [owner, repoName] = repo.full_name.split('/');
      const response = await fetch(`https://api.github.com/repos/${owner}/${repoName}`, {
        headers: {
          'Accept': 'application/vnd.github.v3+json',
        },
      });

      if (response.ok) {
        const data = await response.json();
        realtimeStore.updateRepo(repoId, {
          stargazers_count: data.stargazers_count,
          forks_count: data.forks_count,
          watchers_count: data.watchers_count,
          open_issues_count: data.open_issues_count,
          updated_at: data.updated_at,
        });
      }
    } catch (error) {
      console.error('Error refreshing repo:', error);
    } finally {
      realtimeStore.setUpdating(repoId, false);
    }
  }, []);

  return {
    repos: Array.from(realtimeRepos.values()),
    reposMap: realtimeRepos,
    addRepo,
    removeRepo,
    refreshRepo,
  };
};

// Hook for tracking a single repository
export const useRealtimeRepo = (repo: Repository | null) => {
  const [realtimeRepo, setRealtimeRepo] = useState<RealtimeRepo | null>(null);
  const [lastUpdate, setLastUpdate] = useState<Date | null>(null);

  useEffect(() => {
    if (!repo) {
      setRealtimeRepo(null);
      return;
    }

    const unsubscribe = realtimeStore.subscribe((repos) => {
      const updated = repos.get(repo.id);
      if (updated) {
        setRealtimeRepo(updated);
        setLastUpdate(updated.lastUpdated);
      }
    });

    realtimeStore.addRepo(repo);
    setRealtimeRepo(realtimeStore.getRepo(repo.id) || null);

    return () => {
      unsubscribe();
      realtimeStore.removeRepo(repo.id);
    };
  }, [repo?.id]);

  const refresh = useCallback(async () => {
    if (repo) {
      await realtimeStore['pollRepo'](repo.id);
    }
  }, [repo]);

  return {
    repo: realtimeRepo,
    lastUpdate,
    refresh,
    isUpdating: realtimeRepo?.isUpdating || false,
  };
};

// Hook for live stats with animation
export const useLiveStats = (initialValue: number, currentValue: number) => {
  const [displayValue, setDisplayValue] = useState(initialValue);
  const [isAnimating, setIsAnimating] = useState(false);

  useEffect(() => {
    if (currentValue !== displayValue) {
      setIsAnimating(true);
      
      // Animate the number change
      const duration = 500;
      const startTime = Date.now();
      const startValue = displayValue;
      const diff = currentValue - startValue;

      const animate = () => {
        const elapsed = Date.now() - startTime;
        const progress = Math.min(elapsed / duration, 1);
        
        // Easing function
        const easeOutQuart = 1 - Math.pow(1 - progress, 4);
        
        setDisplayValue(Math.round(startValue + diff * easeOutQuart));

        if (progress < 1) {
          requestAnimationFrame(animate);
        } else {
          setIsAnimating(false);
        }
      };

      requestAnimationFrame(animate);
    }
  }, [currentValue]);

  return { displayValue, isAnimating };
};

export { realtimeStore };
