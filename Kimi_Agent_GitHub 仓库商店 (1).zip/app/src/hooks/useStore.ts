import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import type { Repository, Notification } from '@/types/github';

interface BookmarkedRepo {
  id: number;
  full_name: string;
  added_at: string;
}

interface StoreState {
  // Bookmarks
  bookmarks: BookmarkedRepo[];
  addBookmark: (repo: Repository) => void;
  removeBookmark: (repoId: number) => void;
  isBookmarked: (repoId: number) => boolean;
  
  // Notifications
  notifications: Notification[];
  addNotification: (notification: Notification) => void;
  markNotificationAsRead: (notificationId: string) => void;
  markAllNotificationsAsRead: () => void;
  unreadCount: () => number;
  
  // User preferences
  selectedCategory: string | null;
  setSelectedCategory: (category: string | null) => void;
  
  // Search history
  searchHistory: string[];
  addSearchToHistory: (query: string) => void;
  clearSearchHistory: () => void;
  
  // Recently viewed
  recentlyViewed: BookmarkedRepo[];
  addToRecentlyViewed: (repo: Repository) => void;
}

export const useStore = create<StoreState>()(
  persist(
    (set, get) => ({
      // Bookmarks
      bookmarks: [],
      addBookmark: (repo: Repository) => {
        const { bookmarks } = get();
        if (!bookmarks.find((b) => b.id === repo.id)) {
          set({
            bookmarks: [
              ...bookmarks,
              {
                id: repo.id,
                full_name: repo.full_name,
                added_at: new Date().toISOString(),
              },
            ],
          });
        }
      },
      removeBookmark: (repoId: number) => {
        set({ bookmarks: get().bookmarks.filter((b) => b.id !== repoId) });
      },
      isBookmarked: (repoId: number) => {
        return get().bookmarks.some((b) => b.id === repoId);
      },

      // Notifications
      notifications: [],
      addNotification: (notification: Notification) => {
        set({ notifications: [notification, ...get().notifications] });
      },
      markNotificationAsRead: (notificationId: string) => {
        set({
          notifications: get().notifications.map((n) =>
            n.id === notificationId ? { ...n, read: true } : n
          ),
        });
      },
      markAllNotificationsAsRead: () => {
        set({
          notifications: get().notifications.map((n) => ({ ...n, read: true })),
        });
      },
      unreadCount: () => {
        return get().notifications.filter((n) => !n.read).length;
      },

      // User preferences
      selectedCategory: null,
      setSelectedCategory: (category: string | null) => {
        set({ selectedCategory: category });
      },

      // Search history
      searchHistory: [],
      addSearchToHistory: (query: string) => {
        const { searchHistory } = get();
        const trimmedQuery = query.trim();
        if (trimmedQuery && !searchHistory.includes(trimmedQuery)) {
          set({
            searchHistory: [trimmedQuery, ...searchHistory].slice(0, 10),
          });
        }
      },
      clearSearchHistory: () => {
        set({ searchHistory: [] });
      },

      // Recently viewed
      recentlyViewed: [],
      addToRecentlyViewed: (repo: Repository) => {
        const { recentlyViewed } = get();
        const filtered = recentlyViewed.filter((r) => r.id !== repo.id);
        set({
          recentlyViewed: [
            { id: repo.id, full_name: repo.full_name, added_at: new Date().toISOString() },
            ...filtered,
          ].slice(0, 20),
        });
      },
    }),
    {
      name: 'github-repo-store',
      partialize: (state) => ({
        bookmarks: state.bookmarks,
        searchHistory: state.searchHistory,
        recentlyViewed: state.recentlyViewed,
        selectedCategory: state.selectedCategory,
      }),
    }
  )
);
