import axios from 'axios';
import type {
  Repository,
  RepositoryDetails,
  Release,
  Contributor,
  Commit,
  TrendingRepository,
  User,
} from '@/types/github';

const GITHUB_API_BASE = 'https://api.github.com';

// Create axios instance with default config
const githubClient = axios.create({
  baseURL: GITHUB_API_BASE,
  headers: {
    Accept: 'application/vnd.github.v3+json',
  },
  timeout: 10000,
});

// Add rate limit handling
githubClient.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response?.status === 403) {
      console.warn('GitHub API rate limit exceeded');
    }
    return Promise.reject(error);
  }
);

// Format star count for display
export const formatStarCount = (count: number): string => {
  if (count >= 1000000) {
    return `${(count / 1000000).toFixed(1)}M`;
  }
  if (count >= 1000) {
    return `${(count / 1000).toFixed(1)}k`;
  }
  return count.toString();
};

// Format date for display
export const formatDate = (dateString: string): string => {
  const date = new Date(dateString);
  const now = new Date();
  const diffInDays = Math.floor((now.getTime() - date.getTime()) / (1000 * 60 * 60 * 24));

  if (diffInDays === 0) return 'today';
  if (diffInDays === 1) return 'yesterday';
  if (diffInDays < 7) return `${diffInDays} days ago`;
  if (diffInDays < 30) return `${Math.floor(diffInDays / 7)} weeks ago`;
  if (diffInDays < 365) return `${Math.floor(diffInDays / 30)} months ago`;
  return `${Math.floor(diffInDays / 365)} years ago`;
};

// Search repositories
export const searchRepositories = async (
  query: string,
  sort: 'stars' | 'forks' | 'updated' = 'stars',
  order: 'asc' | 'desc' = 'desc',
  perPage: number = 30,
  page: number = 1
): Promise<Repository[]> => {
  try {
    const response = await githubClient.get('/search/repositories', {
      params: {
        q: query,
        sort,
        order,
        per_page: perPage,
        page,
      },
    });
    return response.data.items;
  } catch (error) {
    console.error('Error searching repositories:', error);
    return [];
  }
};

// Get repository details
export const getRepository = async (
  owner: string,
  repo: string
): Promise<RepositoryDetails | null> => {
  try {
    const response = await githubClient.get(`/repos/${owner}/${repo}`);
    return response.data;
  } catch (error) {
    console.error('Error fetching repository:', error);
    return null;
  }
};

// Get repository releases
export const getReleases = async (
  owner: string,
  repo: string,
  perPage: number = 10
): Promise<Release[]> => {
  try {
    const response = await githubClient.get(`/repos/${owner}/${repo}/releases`, {
      params: { per_page: perPage },
    });
    return response.data;
  } catch (error) {
    console.error('Error fetching releases:', error);
    return [];
  }
};

// Get repository contributors
export const getContributors = async (
  owner: string,
  repo: string,
  perPage: number = 10
): Promise<Contributor[]> => {
  try {
    const response = await githubClient.get(`/repos/${owner}/${repo}/contributors`, {
      params: { per_page: perPage },
    });
    return response.data;
  } catch (error) {
    console.error('Error fetching contributors:', error);
    return [];
  }
};

// Get repository commits
export const getCommits = async (
  owner: string,
  repo: string,
  perPage: number = 10
): Promise<Commit[]> => {
  try {
    const response = await githubClient.get(`/repos/${owner}/${repo}/commits`, {
      params: { per_page: perPage },
    });
    return response.data;
  } catch (error) {
    console.error('Error fetching commits:', error);
    return [];
  }
};

// Get trending repositories (using search with date filter)
export const getTrendingRepositories = async (
  period: 'daily' | 'weekly' | 'monthly' = 'weekly',
  language?: string,
  perPage: number = 10
): Promise<TrendingRepository[]> => {
  try {
    const date = new Date();
    let dateString = '';

    switch (period) {
      case 'daily':
        date.setDate(date.getDate() - 1);
        break;
      case 'weekly':
        date.setDate(date.getDate() - 7);
        break;
      case 'monthly':
        date.setDate(date.getDate() - 30);
        break;
    }

    dateString = date.toISOString().split('T')[0];
    let query = `created:>${dateString}`;
    if (language) {
      query += ` language:${language}`;
    }

    const response = await githubClient.get('/search/repositories', {
      params: {
        q: query,
        sort: 'stars',
        order: 'desc',
        per_page: perPage,
      },
    });

    return response.data.items.map((repo: Repository) => ({
      ...repo,
      trending_stars: repo.stargazers_count,
      trending_period: period,
    }));
  } catch (error) {
    console.error('Error fetching trending repositories:', error);
    return [];
  }
};

// Get repositories by topic
export const getRepositoriesByTopic = async (
  topic: string,
  perPage: number = 30
): Promise<Repository[]> => {
  try {
    const response = await githubClient.get('/search/repositories', {
      params: {
        q: `topic:${topic}`,
        sort: 'stars',
        order: 'desc',
        per_page: perPage,
      },
    });
    return response.data.items;
  } catch (error) {
    console.error('Error fetching repositories by topic:', error);
    return [];
  }
};

// Get user info
export const getUser = async (username: string): Promise<User | null> => {
  try {
    const response = await githubClient.get(`/users/${username}`);
    return response.data;
  } catch (error) {
    console.error('Error fetching user:', error);
    return null;
  }
};

// Get user's repositories
export const getUserRepositories = async (
  username: string,
  perPage: number = 30
): Promise<Repository[]> => {
  try {
    const response = await githubClient.get(`/users/${username}/repos`, {
      params: {
        sort: 'updated',
        per_page: perPage,
      },
    });
    return response.data;
  } catch (error) {
    console.error('Error fetching user repositories:', error);
    return [];
  }
};

// Get featured repositories (popular ones for demo)
export const getFeaturedRepositories = async (): Promise<Repository[]> => {
  const featuredRepos = [
    { owner: 'shadcn', repo: 'ui' },
    { owner: 'facebook', repo: 'react' },
    { owner: 'vercel', repo: 'next.js' },
    { owner: 'microsoft', repo: 'vscode' },
    { owner: 'facebook', repo: 'react-native' },
    { owner: 'tailwindlabs', repo: 'tailwindcss' },
    { owner: 'supabase', repo: 'supabase' },
    { owner: 'aidenybai', repo: 'react-scan' },
  ];

  const repos = await Promise.all(
    featuredRepos.map(({ owner, repo }) => getRepository(owner, repo))
  );

  return repos.filter((repo): repo is RepositoryDetails => repo !== null);
};

// Mock data for when API rate limit is exceeded
export const getMockRepositories = (): Repository[] => [
  {
    id: 1,
    name: 'shadcn/ui',
    full_name: 'shadcn/ui',
    owner: {
      login: 'shadcn',
      avatar_url: 'https://avatars.githubusercontent.com/u/124599?v=4',
      html_url: 'https://github.com/shadcn',
    },
    description: 'Beautifully designed components built with Radix UI and Tailwind CSS.',
    html_url: 'https://github.com/shadcn/ui',
    clone_url: 'https://github.com/shadcn/ui.git',
    homepage: 'https://ui.shadcn.com',
    language: 'TypeScript',
    stargazers_count: 83200,
    forks_count: 2100,
    open_issues_count: 120,
    watchers_count: 83200,
    created_at: '2023-01-01T00:00:00Z',
    updated_at: '2024-01-15T00:00:00Z',
    pushed_at: '2024-01-15T00:00:00Z',
    size: 5000,
    license: { key: 'mit', name: 'MIT License', spdx_id: 'MIT' },
    topics: ['react', 'components', 'ui', 'tailwindcss', 'radix-ui'],
    default_branch: 'main',
    archived: false,
    fork: false,
    private: false,
  },
  {
    id: 2,
    name: 'react',
    full_name: 'facebook/react',
    owner: {
      login: 'facebook',
      avatar_url: 'https://avatars.githubusercontent.com/u/69631?v=4',
      html_url: 'https://github.com/facebook',
    },
    description: 'A declarative, efficient, and flexible JavaScript library for building user interfaces.',
    html_url: 'https://github.com/facebook/react',
    clone_url: 'https://github.com/facebook/react.git',
    homepage: 'https://react.dev',
    language: 'JavaScript',
    stargazers_count: 228000,
    forks_count: 46500,
    open_issues_count: 1200,
    watchers_count: 228000,
    created_at: '2013-05-24T00:00:00Z',
    updated_at: '2024-01-15T00:00:00Z',
    pushed_at: '2024-01-15T00:00:00Z',
    size: 150000,
    license: { key: 'mit', name: 'MIT License', spdx_id: 'MIT' },
    topics: ['javascript', 'react', 'frontend', 'ui'],
    default_branch: 'main',
    archived: false,
    fork: false,
    private: false,
  },
  {
    id: 3,
    name: 'next.js',
    full_name: 'vercel/next.js',
    owner: {
      login: 'vercel',
      avatar_url: 'https://avatars.githubusercontent.com/u/14985020?v=4',
      html_url: 'https://github.com/vercel',
    },
    description: 'The React Framework for the Web.',
    html_url: 'https://github.com/vercel/next.js',
    clone_url: 'https://github.com/vercel/next.js.git',
    homepage: 'https://nextjs.org',
    language: 'TypeScript',
    stargazers_count: 123000,
    forks_count: 26200,
    open_issues_count: 2500,
    watchers_count: 123000,
    created_at: '2016-10-05T00:00:00Z',
    updated_at: '2024-01-15T00:00:00Z',
    pushed_at: '2024-01-15T00:00:00Z',
    size: 200000,
    license: { key: 'mit', name: 'MIT License', spdx_id: 'MIT' },
    topics: ['react', 'framework', 'server-side-rendering', 'static-site-generator'],
    default_branch: 'canary',
    archived: false,
    fork: false,
    private: false,
  },
  {
    id: 4,
    name: 'vscode',
    full_name: 'microsoft/vscode',
    owner: {
      login: 'microsoft',
      avatar_url: 'https://avatars.githubusercontent.com/u/6154722?v=4',
      html_url: 'https://github.com/microsoft',
    },
    description: 'Visual Studio Code.',
    html_url: 'https://github.com/microsoft/vscode',
    clone_url: 'https://github.com/microsoft/vscode.git',
    homepage: 'https://code.visualstudio.com',
    language: 'TypeScript',
    stargazers_count: 159000,
    forks_count: 27800,
    open_issues_count: 8000,
    watchers_count: 159000,
    created_at: '2015-09-03T00:00:00Z',
    updated_at: '2024-01-15T00:00:00Z',
    pushed_at: '2024-01-15T00:00:00Z',
    size: 500000,
    license: { key: 'mit', name: 'MIT License', spdx_id: 'MIT' },
    topics: ['editor', 'ide', 'typescript', 'electron'],
    default_branch: 'main',
    archived: false,
    fork: false,
    private: false,
  },
  {
    id: 5,
    name: 'tailwindcss',
    full_name: 'tailwindlabs/tailwindcss',
    owner: {
      login: 'tailwindlabs',
      avatar_url: 'https://avatars.githubusercontent.com/u/67109815?v=4',
      html_url: 'https://github.com/tailwindlabs',
    },
    description: 'A utility-first CSS framework for rapid UI development.',
    html_url: 'https://github.com/tailwindlabs/tailwindcss',
    clone_url: 'https://github.com/tailwindlabs/tailwindcss.git',
    homepage: 'https://tailwindcss.com',
    language: 'CSS',
    stargazers_count: 82000,
    forks_count: 4100,
    open_issues_count: 300,
    watchers_count: 82000,
    created_at: '2017-10-06T00:00:00Z',
    updated_at: '2024-01-15T00:00:00Z',
    pushed_at: '2024-01-15T00:00:00Z',
    size: 80000,
    license: { key: 'mit', name: 'MIT License', spdx_id: 'MIT' },
    topics: ['css', 'framework', 'utility-first', 'design-system'],
    default_branch: 'master',
    archived: false,
    fork: false,
    private: false,
  },
  {
    id: 6,
    name: 'supabase',
    full_name: 'supabase/supabase',
    owner: {
      login: 'supabase',
      avatar_url: 'https://avatars.githubusercontent.com/u/54469796?v=4',
      html_url: 'https://github.com/supabase',
    },
    description: 'The open source Firebase alternative.',
    html_url: 'https://github.com/supabase/supabase',
    clone_url: 'https://github.com/supabase/supabase.git',
    homepage: 'https://supabase.com',
    language: 'TypeScript',
    stargazers_count: 65000,
    forks_count: 3100,
    open_issues_count: 450,
    watchers_count: 65000,
    created_at: '2019-09-10T00:00:00Z',
    updated_at: '2024-01-15T00:00:00Z',
    pushed_at: '2024-01-15T00:00:00Z',
    size: 120000,
    license: { key: 'apache-2.0', name: 'Apache License 2.0', spdx_id: 'Apache-2.0' },
    topics: ['postgresql', 'realtime', 'auth', 'storage', 'firebase-alternative'],
    default_branch: 'master',
    archived: false,
    fork: false,
    private: false,
  },
];
