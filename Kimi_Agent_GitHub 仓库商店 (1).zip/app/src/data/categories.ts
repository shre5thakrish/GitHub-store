import type { Category } from '@/types/github';

export const categories: Category[] = [
  {
    id: 'web',
    name: 'Web Development',
    description: 'Frontend frameworks, UI libraries, and web tools',
    icon: 'Globe',
    color: '#3B82F6',
    topic: 'web',
  },
  {
    id: 'mobile',
    name: 'Mobile Apps',
    description: 'React Native, Flutter, and mobile development tools',
    icon: 'Smartphone',
    color: '#8B5CF6',
    topic: 'mobile',
  },
  {
    id: 'ai',
    name: 'AI / ML',
    description: 'Machine learning, AI tools, and data science libraries',
    icon: 'Brain',
    color: '#EC4899',
    topic: 'machine-learning',
  },
  {
    id: 'devtools',
    name: 'DevTools',
    description: 'Developer tools, CLI utilities, and productivity apps',
    icon: 'Wrench',
    color: '#10B981',
    topic: 'developer-tools',
  },
  {
    id: 'games',
    name: 'Games',
    description: 'Game engines, frameworks, and gaming libraries',
    icon: 'Gamepad2',
    color: '#F59E0B',
    topic: 'game-development',
  },
  {
    id: 'data',
    name: 'Data',
    description: 'Databases, data processing, and analytics tools',
    icon: 'Database',
    color: '#06B6D4',
    topic: 'database',
  },
];

export const getCategoryById = (id: string): Category | undefined => {
  return categories.find((cat) => cat.id === id);
};

export const getCategoryByTopic = (topic: string): Category | undefined => {
  return categories.find((cat) => cat.topic === topic);
};
