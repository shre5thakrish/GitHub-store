import type { Review } from '@/types/github';

export const mockReviews: Review[] = [
  {
    id: '1',
    user: {
      login: 'alexdev',
      avatar_url: 'https://avatars.githubusercontent.com/u/1?v=4',
    },
    rating: 5,
    comment: 'Clean API, great docs. This library has completely transformed how I build UIs. The component design is intuitive and the theming system is incredibly flexible.',
    created_at: '2024-01-10T00:00:00Z',
  },
  {
    id: '2',
    user: {
      login: 'sarahbuilds',
      avatar_url: 'https://avatars.githubusercontent.com/u/2?v=4',
    },
    rating: 5,
    comment: 'Saved me weeks of UI work. The pre-built components are production-ready and accessibility is built-in. Highly recommend for any React project.',
    created_at: '2024-01-08T00:00:00Z',
  },
  {
    id: '3',
    user: {
      login: 'jordan_ui',
      avatar_url: 'https://avatars.githubusercontent.com/u/3?v=4',
    },
    rating: 5,
    comment: 'The theming system is genius. Being able to customize every aspect of the design with just a few configuration changes is a game changer.',
    created_at: '2024-01-05T00:00:00Z',
  },
  {
    id: '4',
    user: {
      login: 'mikecodes',
      avatar_url: 'https://avatars.githubusercontent.com/u/4?v=4',
    },
    rating: 4,
    comment: 'Excellent component library. Would love to see more advanced components like data tables and charts. Overall very satisfied with the quality.',
    created_at: '2024-01-03T00:00:00Z',
  },
  {
    id: '5',
    user: {
      login: 'emmatech',
      avatar_url: 'https://avatars.githubusercontent.com/u/5?v=4',
    },
    rating: 5,
    comment: 'Best UI library I have used. The copy-paste approach gives you full control while maintaining consistency across your application.',
    created_at: '2024-01-01T00:00:00Z',
  },
  {
    id: '6',
    user: {
      login: 'davidreact',
      avatar_url: 'https://avatars.githubusercontent.com/u/6?v=4',
    },
    rating: 5,
    comment: 'TypeScript support is top-notch. Everything is properly typed and the IntelliSense experience is excellent. A must-have for type-safe development.',
    created_at: '2023-12-28T00:00:00Z',
  },
];

export const getAverageRating = (reviews: Review[]): number => {
  if (reviews.length === 0) return 0;
  const sum = reviews.reduce((acc, review) => acc + review.rating, 0);
  return Math.round((sum / reviews.length) * 10) / 10;
};

export const getRatingDistribution = (reviews: Review[]): Record<number, number> => {
  const distribution: Record<number, number> = { 1: 0, 2: 0, 3: 0, 4: 0, 5: 0 };
  reviews.forEach((review) => {
    distribution[review.rating]++;
  });
  return distribution;
};
