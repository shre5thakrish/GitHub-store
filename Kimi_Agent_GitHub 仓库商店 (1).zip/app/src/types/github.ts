export interface Repository {
  id: number;
  name: string;
  full_name: string;
  owner: {
    login: string;
    avatar_url: string;
    html_url: string;
  };
  description: string | null;
  html_url: string;
  clone_url: string;
  homepage: string | null;
  language: string | null;
  stargazers_count: number;
  forks_count: number;
  open_issues_count: number;
  watchers_count: number;
  created_at: string;
  updated_at: string;
  pushed_at: string;
  size: number;
  license: {
    key: string;
    name: string;
    spdx_id: string;
  } | null;
  topics: string[];
  default_branch: string;
  archived: boolean;
  fork: boolean;
  private: boolean;
}

export interface RepositoryDetails extends Repository {
  subscribers_count: number;
  network_count: number;
  allow_forking: boolean;
  has_issues: boolean;
  has_projects: boolean;
  has_downloads: boolean;
  has_wiki: boolean;
  has_pages: boolean;
  has_discussions: boolean;
  forks: number;
  open_issues: number;
  watchers: number;
}

export interface Release {
  id: number;
  tag_name: string;
  name: string | null;
  body: string | null;
  created_at: string;
  published_at: string;
  prerelease: boolean;
  draft: boolean;
  author: {
    login: string;
    avatar_url: string;
  };
  html_url: string;
  tarball_url: string;
  zipball_url: string;
  assets: {
    name: string;
    size: number;
    download_count: number;
    browser_download_url: string;
  }[];
}

export interface Contributor {
  id: number;
  login: string;
  avatar_url: string;
  html_url: string;
  contributions: number;
}

export interface Commit {
  sha: string;
  commit: {
    message: string;
    author: {
      name: string;
      email: string;
      date: string;
    };
  };
  author: {
    login: string;
    avatar_url: string;
  } | null;
  html_url: string;
}

export interface TrendingRepository extends Repository {
  trending_stars: number;
  trending_period: 'daily' | 'weekly' | 'monthly';
}

export interface Category {
  id: string;
  name: string;
  description: string;
  icon: string;
  color: string;
  topic: string;
}

export interface Review {
  id: string;
  user: {
    login: string;
    avatar_url: string;
  };
  rating: number;
  comment: string;
  created_at: string;
}

export interface User {
  login: string;
  id: number;
  avatar_url: string;
  html_url: string;
  name: string | null;
  bio: string | null;
  location: string | null;
  company: string | null;
  blog: string | null;
  twitter_username: string | null;
  public_repos: number;
  public_gists: number;
  followers: number;
  following: number;
  created_at: string;
}

export interface Notification {
  id: string;
  type: 'release' | 'commit' | 'star' | 'fork' | 'issue';
  repository: string;
  message: string;
  created_at: string;
  read: boolean;
}

export type TimeRange = 'daily' | 'weekly' | 'monthly';
