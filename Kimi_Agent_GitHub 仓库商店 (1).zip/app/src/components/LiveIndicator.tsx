import { useState, useEffect } from 'react';
import { Wifi, WifiOff, RefreshCw } from 'lucide-react';

interface LiveIndicatorProps {
  lastUpdate: Date | null;
  isUpdating?: boolean;
  onRefresh?: () => void;
  size?: 'sm' | 'md';
}

export function LiveIndicator({ lastUpdate, isUpdating = false, onRefresh, size = 'sm' }: LiveIndicatorProps) {
  const [timeAgo, setTimeAgo] = useState<string>('');
  const [isOnline, setIsOnline] = useState(navigator.onLine);

  useEffect(() => {
    const updateTimeAgo = () => {
      if (!lastUpdate) {
        setTimeAgo('');
        return;
      }

      const now = new Date();
      const diff = now.getTime() - lastUpdate.getTime();
      const seconds = Math.floor(diff / 1000);
      const minutes = Math.floor(seconds / 60);
      const hours = Math.floor(minutes / 60);

      if (seconds < 10) {
        setTimeAgo('just now');
      } else if (seconds < 60) {
        setTimeAgo(`${seconds}s ago`);
      } else if (minutes < 60) {
        setTimeAgo(`${minutes}m ago`);
      } else if (hours < 24) {
        setTimeAgo(`${hours}h ago`);
      } else {
        setTimeAgo(lastUpdate.toLocaleDateString());
      }
    };

    updateTimeAgo();
    const interval = setInterval(updateTimeAgo, 5000);

    return () => clearInterval(interval);
  }, [lastUpdate]);

  useEffect(() => {
    const handleOnline = () => setIsOnline(true);
    const handleOffline = () => setIsOnline(false);

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  const iconSize = size === 'sm' ? 'w-3 h-3' : 'w-4 h-4';
  const textSize = size === 'sm' ? 'text-[10px]' : 'text-xs';

  return (
    <div className={`flex items-center gap-1.5 ${textSize}`}>
      {/* Online/Offline Status */}
      {isOnline ? (
        <Wifi className={`${iconSize} text-green-500`} />
      ) : (
        <WifiOff className={`${iconSize} text-red-500`} />
      )}

      {/* Live Pulse */}
      {isOnline && !isUpdating && (
        <span className="relative flex h-2 w-2">
          <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-green-400 opacity-75"></span>
          <span className="relative inline-flex rounded-full h-2 w-2 bg-green-500"></span>
        </span>
      )}

      {/* Updating Spinner */}
      {isUpdating && (
        <RefreshCw className={`${iconSize} text-blue-500 animate-spin`} />
      )}

      {/* Time Ago */}
      {timeAgo && (
        <span className="text-slate-400">
          updated {timeAgo}
        </span>
      )}

      {/* Refresh Button */}
      {onRefresh && !isUpdating && (
        <button
          onClick={onRefresh}
          className="p-1 hover:bg-slate-100 rounded transition-colors"
          title="Refresh now"
        >
          <RefreshCw className={`${iconSize} text-slate-400 hover:text-blue-500`} />
        </button>
      )}
    </div>
  );
}

// Animated number component for live stats
interface AnimatedNumberProps {
  value: number;
  isAnimating?: boolean;
  className?: string;
}

export function AnimatedNumber({ value, isAnimating = false, className = '' }: AnimatedNumberProps) {
  return (
    <span className={`tabular-nums transition-colors duration-300 ${isAnimating ? 'text-green-600' : ''} ${className}`}>
      {value.toLocaleString()}
    </span>
  );
}

// Live stat change indicator
interface StatChangeIndicatorProps {
  previousValue: number;
  currentValue: number;
}

export function StatChangeIndicator({ previousValue, currentValue }: StatChangeIndicatorProps) {
  const diff = currentValue - previousValue;
  
  if (diff === 0) return null;

  const isPositive = diff > 0;

  return (
    <span
      className={`inline-flex items-center gap-0.5 text-[10px] font-medium px-1.5 py-0.5 rounded-full ${
        isPositive
          ? 'bg-green-100 text-green-700'
          : 'bg-red-100 text-red-700'
      }`}
    >
      {isPositive ? '+' : ''}{diff.toLocaleString()}
    </span>
  );
}
