import { useEffect, useState } from 'react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  Star,
  GitFork,
  Eye,
  Circle,
  ExternalLink,
  Bookmark,
  BookmarkCheck,
  Github,
  Code,
  FileText,
  Users,
  Tag,
  Calendar,
  Share2,
  Copy,
  Check,
  Info,
  TrendingUp,
  Activity,
} from 'lucide-react';
import { getRepository, getContributors, getReleases, formatDate } from '@/services/githubApi';
import { useStore } from '@/hooks/useStore';
import { useRealtimeRepo, useLiveStats } from '@/hooks/useRealtimeRepos';
import { LiveIndicator, AnimatedNumber, StatChangeIndicator } from '@/components/LiveIndicator';
import type { RepositoryDetails, Contributor, Release } from '@/types/github';

interface RepoDetailModalProps {
  repoFullName: string | null;
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

const languageColors: Record<string, string> = {
  TypeScript: '#3178C6',
  JavaScript: '#F7DF1E',
  Python: '#3776AB',
  Java: '#007396',
  Go: '#00ADD8',
  Rust: '#DEA584',
  'C++': '#F34B7D',
  C: '#555555',
  'C#': '#239120',
  Ruby: '#CC342D',
  PHP: '#4F5D95',
  Swift: '#FFAC45',
  Kotlin: '#A97BFF',
  Dart: '#00B4AB',
  CSS: '#563D7C',
  HTML: '#E34C26',
  Shell: '#89E051',
  Vue: '#4FC08D',
};

export function RepoDetailModal({ repoFullName, open, onOpenChange }: RepoDetailModalProps) {
  const [repo, setRepo] = useState<RepositoryDetails | null>(null);
  const [contributors, setContributors] = useState<Contributor[]>([]);
  const [releases, setReleases] = useState<Release[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [activeTab, setActiveTab] = useState('overview');
  const [copied, setCopied] = useState(false);

  const { addBookmark, removeBookmark, isBookmarked, addToRecentlyViewed } = useStore();
  const bookmarked = repo ? isBookmarked(repo.id) : false;

  // Real-time updates
  const { repo: realtimeRepo, lastUpdate, refresh, isUpdating } = useRealtimeRepo(repo);
  
  // Animated stats
  const { displayValue: displayStars, isAnimating: starsAnimating } = useLiveStats(
    repo?.stargazers_count || 0,
    realtimeRepo?.stargazers_count || repo?.stargazers_count || 0
  );
  const { displayValue: displayForks, isAnimating: forksAnimating } = useLiveStats(
    repo?.forks_count || 0,
    realtimeRepo?.forks_count || repo?.forks_count || 0
  );
  const { displayValue: displayWatchers, isAnimating: watchersAnimating } = useLiveStats(
    repo?.watchers_count || 0,
    realtimeRepo?.watchers_count || repo?.watchers_count || 0
  );

  useEffect(() => {
    if (!repoFullName || !open) return;

    const loadRepoData = async () => {
      setIsLoading(true);
      const [owner, repoName] = repoFullName.split('/');
      
      const repoData = await getRepository(owner, repoName);
      if (repoData) {
        setRepo(repoData);
        addToRecentlyViewed(repoData);

        const [contributorsData, releasesData] = await Promise.all([
          getContributors(owner, repoName, 10),
          getReleases(owner, repoName, 5),
        ]);

        setContributors(contributorsData);
        setReleases(releasesData);
      }
      setIsLoading(false);
    };

    loadRepoData();
  }, [repoFullName, open, addToRecentlyViewed]);

  const handleBookmark = () => {
    if (!repo) return;
    if (bookmarked) {
      removeBookmark(repo.id);
    } else {
      addBookmark(repo);
    }
  };

  const handleShare = async () => {
    if (!repo) return;
    try {
      await navigator.share({
        title: repo.name,
        text: repo.description || '',
        url: repo.html_url,
      });
    } catch {
      navigator.clipboard.writeText(repo.html_url);
    }
  };

  const handleCopyClone = () => {
    if (!repo) return;
    navigator.clipboard.writeText(repo.clone_url);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const languageColor = repo?.language
    ? languageColors[repo.language] || '#64748B'
    : '#64748B';

  // Calculate trend
  const currentRepo = realtimeRepo || repo;
  const starDiff = currentRepo && repo 
    ? currentRepo.stargazers_count - repo.stargazers_count 
    : 0;

  if (isLoading) {
    return (
      <Dialog open={open} onOpenChange={onOpenChange}>
        <DialogContent className="max-w-3xl bg-white border-slate-200 p-0 overflow-hidden">
          <div className="p-6 sm:p-8">
            <div className="flex items-center gap-4 mb-6">
              <div className="w-16 h-16 rounded-2xl bg-slate-100 animate-pulse" />
              <div className="flex-1">
                <div className="h-6 w-48 bg-slate-100 rounded-lg mb-2 animate-pulse" />
                <div className="h-4 w-32 bg-slate-100 rounded animate-pulse" />
              </div>
            </div>
            <div className="space-y-3">
              <div className="h-4 w-full bg-slate-100 rounded-lg animate-pulse" />
              <div className="h-4 w-3/4 bg-slate-100 rounded-lg animate-pulse" />
            </div>
          </div>
        </DialogContent>
      </Dialog>
    );
  }

  if (!repo) {
    return (
      <Dialog open={open} onOpenChange={onOpenChange}>
        <DialogContent className="max-w-lg bg-white border-slate-200">
          <div className="text-center py-10">
            <div className="w-16 h-16 bg-slate-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <Info className="w-8 h-8 text-slate-400" />
            </div>
            <p className="text-slate-600 font-medium mb-1">Repository not found</p>
            <p className="text-sm text-slate-500">Try searching for another repository</p>
          </div>
        </DialogContent>
      </Dialog>
    );
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-3xl bg-white border-slate-200 p-0 gap-0 overflow-hidden max-h-[90vh] overflow-y-auto">
        {/* Live Update Banner */}
        {starDiff > 0 && (
          <div className="bg-green-50 border-b border-green-100 px-4 py-2 flex items-center justify-between">
            <div className="flex items-center gap-2 text-green-700 text-sm">
              <Activity className="w-4 h-4" />
              <span>+{starDiff} new stars since you opened this!</span>
            </div>
            <LiveIndicator 
              lastUpdate={lastUpdate} 
              isUpdating={isUpdating}
              onRefresh={refresh}
              size="sm"
            />
          </div>
        )}

        {/* Header */}
        <div className="p-4 sm:p-6 border-b border-slate-100">
          <div className="flex items-start gap-3 sm:gap-4">
            <img
              src={repo.owner.avatar_url}
              alt={repo.owner.login}
              className="w-12 h-12 sm:w-16 sm:h-16 rounded-xl bg-slate-100 flex-shrink-0"
            />
            <div className="flex-1 min-w-0">
              <DialogHeader className="text-left">
                <DialogTitle className="text-xl sm:text-2xl font-bold text-slate-900 truncate flex items-center gap-2">
                  {repo.name}
                  {starDiff > 0 && (
                    <span className="inline-flex items-center gap-1 px-2 py-0.5 bg-green-100 text-green-700 text-xs font-medium rounded-full">
                      <TrendingUp className="w-3 h-3" />
                      +{starDiff}
                    </span>
                  )}
                </DialogTitle>
              </DialogHeader>
              <p className="text-sm text-slate-500">
                by{' '}
                <a
                  href={repo.owner.html_url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-blue-600 hover:underline"
                >
                  {repo.owner.login}
                </a>
              </p>
            </div>
            <div className="flex items-center gap-1 flex-shrink-0">
              <Button
                variant="ghost"
                size="icon"
                className="text-slate-400 hover:text-blue-600 hover:bg-blue-50 h-9 w-9"
                onClick={handleShare}
                title="Share"
              >
                <Share2 className="w-4 h-4" />
              </Button>
              <Button
                variant="ghost"
                size="icon"
                className={`h-9 w-9 ${
                  bookmarked
                    ? 'text-blue-600'
                    : 'text-slate-400 hover:text-blue-600'
                } hover:bg-blue-50`}
                onClick={handleBookmark}
                title={bookmarked ? 'Remove bookmark' : 'Add bookmark'}
              >
                {bookmarked ? <BookmarkCheck className="w-5 h-5" /> : <Bookmark className="w-5 h-5" />}
              </Button>
            </div>
          </div>

          {/* Description */}
          {repo.description && (
            <p className="mt-3 text-slate-600 text-sm sm:text-base">{repo.description}</p>
          )}

          {/* Stats Row with Live Updates */}
          <div className="flex flex-wrap items-center gap-3 sm:gap-4 mt-4 pt-4 border-t border-slate-100">
            <div className="flex items-center gap-1.5 text-slate-600" title="Stars">
              <Star className="w-4 h-4 fill-amber-400 text-amber-400" />
              <AnimatedNumber 
                value={displayStars}
                isAnimating={starsAnimating}
                className="text-sm font-medium"
              />
              <StatChangeIndicator 
                previousValue={repo.stargazers_count}
                currentValue={currentRepo?.stargazers_count || repo.stargazers_count}
              />
            </div>
            <div className="flex items-center gap-1.5 text-slate-600" title="Forks">
              <GitFork className="w-4 h-4 text-slate-400" />
              <AnimatedNumber 
                value={displayForks}
                isAnimating={forksAnimating}
                className="text-sm font-medium"
              />
            </div>
            <div className="flex items-center gap-1.5 text-slate-600" title="Watchers">
              <Eye className="w-4 h-4 text-slate-400" />
              <AnimatedNumber 
                value={displayWatchers}
                isAnimating={watchersAnimating}
                className="text-sm font-medium"
              />
            </div>
            {repo.language && (
              <div className="flex items-center gap-1.5 text-slate-600">
                <Circle
                  className="w-3 h-3"
                  style={{ color: languageColor, fill: languageColor }}
                />
                <span className="text-sm font-medium">{repo.language}</span>
              </div>
            )}
            {repo.license && (
              <Badge
                variant="secondary"
                className="text-xs bg-slate-100 text-slate-600 border-none"
              >
                {repo.license.name}
              </Badge>
            )}
          </div>

          {/* Live Indicator */}
          <div className="mt-3 flex items-center justify-between">
            <LiveIndicator 
              lastUpdate={lastUpdate} 
              isUpdating={isUpdating}
              onRefresh={refresh}
              size="sm"
            />
            <span className="text-xs text-slate-400">
              Auto-refreshes every 30s
            </span>
          </div>

          {/* Action Buttons */}
          <div className="flex flex-wrap items-center gap-2 mt-4">
            <a
              href={repo.html_url}
              target="_blank"
              rel="noopener noreferrer"
              className="flex-1 sm:flex-none"
            >
              <Button className="w-full sm:w-auto bg-slate-900 hover:bg-slate-800 text-white">
                <Github className="w-4 h-4 mr-2" />
                View on GitHub
              </Button>
            </a>
            {repo.homepage && (
              <a href={repo.homepage} target="_blank" rel="noopener noreferrer" className="flex-1 sm:flex-none">
                <Button variant="outline" className="w-full sm:w-auto border-slate-200 text-slate-700 hover:bg-slate-50">
                  <ExternalLink className="w-4 h-4 mr-2" />
                  Website
                </Button>
              </a>
            )}
          </div>
        </div>

        {/* Tabs */}
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="w-full justify-start rounded-none border-b border-slate-100 bg-slate-50/50 p-0 px-4 overflow-x-auto">
            <TabsTrigger
              value="overview"
              className="rounded-none border-b-2 border-transparent data-[state=active]:border-blue-500 data-[state=active]:bg-white data-[state=active]:text-slate-900 px-3 sm:px-4 py-3 text-sm"
            >
              <FileText className="w-4 h-4 mr-1.5 sm:mr-2" />
              <span className="hidden sm:inline">Overview</span>
              <span className="sm:hidden">Info</span>
            </TabsTrigger>
            <TabsTrigger
              value="code"
              className="rounded-none border-b-2 border-transparent data-[state=active]:border-blue-500 data-[state=active]:bg-white data-[state=active]:text-slate-900 px-3 sm:px-4 py-3 text-sm"
            >
              <Code className="w-4 h-4 mr-1.5 sm:mr-2" />
              Code
            </TabsTrigger>
            <TabsTrigger
              value="contributors"
              className="rounded-none border-b-2 border-transparent data-[state=active]:border-blue-500 data-[state=active]:bg-white data-[state=active]:text-slate-900 px-3 sm:px-4 py-3 text-sm"
            >
              <Users className="w-4 h-4 mr-1.5 sm:mr-2" />
              <span className="hidden sm:inline">Contributors</span>
              <span className="sm:hidden">People</span>
            </TabsTrigger>
            <TabsTrigger
              value="releases"
              className="rounded-none border-b-2 border-transparent data-[state=active]:border-blue-500 data-[state=active]:bg-white data-[state=active]:text-slate-900 px-3 sm:px-4 py-3 text-sm"
            >
              <Tag className="w-4 h-4 mr-1.5 sm:mr-2" />
              <span className="hidden sm:inline">Releases</span>
              <span className="sm:hidden">Versions</span>
            </TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="p-4 sm:p-6 mt-0">
            <div className="space-y-4 sm:space-y-6">
              {/* Topics */}
              {repo.topics && repo.topics.length > 0 && (
                <div>
                  <h3 className="text-sm font-medium text-slate-700 mb-3">
                    Topics
                  </h3>
                  <div className="flex flex-wrap gap-2">
                    {repo.topics.map((topic) => (
                      <Badge
                        key={topic}
                        variant="outline"
                        className="border-slate-200 text-slate-600 hover:border-blue-300 hover:text-blue-600 cursor-pointer"
                      >
                        {topic}
                      </Badge>
                    ))}
                  </div>
                </div>
              )}

              {/* Info Grid */}
              <div className="grid grid-cols-2 gap-3 sm:gap-4">
                <div className="p-3 sm:p-4 bg-slate-50 rounded-xl">
                  <div className="flex items-center gap-2 text-slate-500 mb-1">
                    <Calendar className="w-4 h-4" />
                    <span className="text-xs sm:text-sm">Created</span>
                  </div>
                  <p className="text-slate-900 font-medium text-sm sm:text-base">
                    {formatDate(repo.created_at)}
                  </p>
                </div>
                <div className="p-3 sm:p-4 bg-slate-50 rounded-xl">
                  <div className="flex items-center gap-2 text-slate-500 mb-1">
                    <Calendar className="w-4 h-4" />
                    <span className="text-xs sm:text-sm">Last Updated</span>
                  </div>
                  <p className="text-slate-900 font-medium text-sm sm:text-base">
                    {formatDate(repo.updated_at)}
                  </p>
                </div>
              </div>

              {/* Default Branch */}
              <div className="p-3 sm:p-4 bg-slate-50 rounded-xl">
                <div className="flex items-center gap-2 text-slate-500 mb-1">
                  <Code className="w-4 h-4" />
                  <span className="text-xs sm:text-sm">Default Branch</span>
                </div>
                <p className="text-slate-900 font-medium text-sm sm:text-base">{repo.default_branch}</p>
              </div>
            </div>
          </TabsContent>

          <TabsContent value="code" className="p-4 sm:p-6 mt-0">
            <div className="space-y-4">
              {/* Clone URL */}
              <div className="p-4 bg-slate-50 rounded-xl">
                <h3 className="text-sm font-medium text-slate-700 mb-2">
                  Clone this repository
                </h3>
                <div className="flex items-center gap-2">
                  <code className="flex-1 p-3 bg-white border border-slate-200 rounded-lg text-sm text-slate-700 font-mono break-all">
                    git clone {repo.clone_url}
                  </code>
                  <Button
                    variant="outline"
                    size="icon"
                    className="h-11 w-11 border-slate-200 flex-shrink-0"
                    onClick={handleCopyClone}
                  >
                    {copied ? <Check className="w-4 h-4 text-green-600" /> : <Copy className="w-4 h-4" />}
                  </Button>
                </div>
                <p className="text-xs text-slate-500 mt-2">
                  Run this command in your terminal to download the code
                </p>
              </div>

              {/* Quick Stats */}
              <div className="grid grid-cols-2 gap-3 sm:gap-4">
                <div className="p-3 sm:p-4 bg-slate-50 rounded-xl">
                  <p className="text-xs sm:text-sm text-slate-500 mb-1">Repository Size</p>
                  <p className="text-slate-900 font-medium text-sm sm:text-base">
                    {(repo.size / 1024).toFixed(1)} MB
                  </p>
                </div>
                <div className="p-3 sm:p-4 bg-slate-50 rounded-xl">
                  <p className="text-xs sm:text-sm text-slate-500 mb-1">Open Issues</p>
                  <p className="text-slate-900 font-medium text-sm sm:text-base">
                    {repo.open_issues_count}
                  </p>
                </div>
              </div>
            </div>
          </TabsContent>

          <TabsContent value="contributors" className="p-4 sm:p-6 mt-0">
            {contributors.length > 0 ? (
              <div className="space-y-2">
                <p className="text-sm text-slate-500 mb-3">
                  Top contributors to this project
                </p>
                {contributors.map((contributor) => (
                  <a
                    key={contributor.id}
                    href={contributor.html_url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center gap-3 p-3 bg-slate-50 rounded-xl hover:bg-blue-50 transition-colors"
                  >
                    <img
                      src={contributor.avatar_url}
                      alt={contributor.login}
                      className="w-10 h-10 rounded-lg bg-slate-200"
                      loading="lazy"
                    />
                    <div className="flex-1">
                      <p className="font-medium text-slate-900">
                        {contributor.login}
                      </p>
                    </div>
                    <div className="text-right">
                      <p className="text-sm text-slate-500">
                        {contributor.contributions} commits
                      </p>
                    </div>
                  </a>
                ))}
              </div>
            ) : (
              <div className="text-center py-8">
                <Users className="w-12 h-12 text-slate-300 mx-auto mb-3" />
                <p className="text-slate-600 font-medium">No contributors data</p>
                <p className="text-sm text-slate-500">Contributor information is not available</p>
              </div>
            )}
          </TabsContent>

          <TabsContent value="releases" className="p-4 sm:p-6 mt-0">
            {releases.length > 0 ? (
              <div className="space-y-3">
                <p className="text-sm text-slate-500 mb-3">
                  Latest versions of this project
                </p>
                {releases.map((release) => (
                  <div
                    key={release.id}
                    className="p-4 bg-slate-50 rounded-xl"
                  >
                    <div className="flex items-start justify-between gap-3 mb-2">
                      <a
                        href={release.html_url}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="font-medium text-slate-900 hover:text-blue-600 transition-colors"
                      >
                        {release.name || release.tag_name}
                      </a>
                      <Badge
                        variant={release.prerelease ? 'destructive' : 'secondary'}
                        className={
                          release.prerelease
                            ? 'bg-amber-100 text-amber-700 border-none'
                            : 'bg-green-100 text-green-700 border-none'
                        }
                      >
                        {release.prerelease ? 'Beta' : 'Stable'}
                      </Badge>
                    </div>
                    <p className="text-sm text-slate-500 mb-2">
                      Released {formatDate(release.published_at)}
                    </p>
                    {release.body && (
                      <p className="text-sm text-slate-600 line-clamp-3">
                        {release.body}
                      </p>
                    )}
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-8">
                <Tag className="w-12 h-12 text-slate-300 mx-auto mb-3" />
                <p className="text-slate-600 font-medium">No releases yet</p>
                <p className="text-sm text-slate-500">This project hasn&apos;t published any releases</p>
              </div>
            )}
          </TabsContent>
        </Tabs>
      </DialogContent>
    </Dialog>
  );
}
