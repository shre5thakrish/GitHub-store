import { useState, useEffect } from 'react';
import { Search, Bell, Menu, X, Bookmark, Github, HelpCircle, Sparkles, LogOut, RefreshCw } from 'lucide-react';
import { Button } from '@/components/ui/button';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { useStore } from '@/hooks/useStore';
import { useAuth } from '@/hooks/useAuth';

interface NavigationProps {
  onSearchClick?: () => void;
}

export function Navigation({ onSearchClick }: NavigationProps) {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const { bookmarks, unreadCount, markAllNotificationsAsRead } = useStore();
  const { user, isAuthenticated, logout } = useAuth();

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const unread = unreadCount();

  const navLinks = [
    { label: 'Browse', href: '#browse', icon: Sparkles },
    { label: 'Trending', href: '#trending', icon: RefreshCw },
    { label: 'Categories', href: '#categories', icon: Menu },
  ];

  const handleLogin = () => {
    // For demo purposes, show a mock login
    alert('GitHub Login would open here!\n\nIn production, this would:\n1. Open GitHub OAuth\n2. Request user permissions\n3. Fetch your profile data\n4. Show your repos and activity');
  };

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        isScrolled
          ? 'bg-white/95 backdrop-blur-md shadow-sm'
          : 'bg-transparent'
      }`}
    >
      <nav className="flex items-center justify-between h-16 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto">
        {/* Logo */}
        <a href="/" className="flex items-center gap-2.5 group">
          <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-blue-500 to-indigo-600 flex items-center justify-center shadow-md">
            <Github className="w-5 h-5 text-white" />
          </div>
          <div className="hidden sm:block">
            <span className="text-lg font-bold text-slate-900">Repo Store</span>
            <span className="text-xs text-slate-500 block -mt-0.5 flex items-center gap-1">
              <span className="relative flex h-1.5 w-1.5">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-green-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-1.5 w-1.5 bg-green-500"></span>
              </span>
              Live Updates
            </span>
          </div>
        </a>

        {/* Desktop Navigation */}
        <div className="hidden md:flex items-center gap-1">
          {navLinks.map((link) => (
            <a
              key={link.label}
              href={link.href}
              className="px-4 py-2 text-sm font-medium text-slate-600 hover:text-blue-600 hover:bg-blue-50 rounded-lg transition-colors"
            >
              {link.label}
            </a>
          ))}
        </div>

        {/* Right Actions */}
        <div className="flex items-center gap-1.5">
          {/* Search Button - Desktop */}
          <Button
            variant="ghost"
            size="sm"
            className="hidden sm:flex items-center gap-2 text-slate-600 hover:text-blue-600 hover:bg-blue-50 h-10 px-3"
            onClick={onSearchClick}
          >
            <Search className="w-4 h-4" />
            <span className="text-sm">Search</span>
            <kbd className="hidden lg:inline-flex items-center gap-1 px-1.5 py-0.5 text-xs font-mono text-slate-400 bg-slate-100 rounded">
              ⌘K
            </kbd>
          </Button>

          {/* Mobile Search */}
          <Button
            variant="ghost"
            size="icon"
            className="sm:hidden text-slate-600 hover:text-blue-600 hover:bg-blue-50 h-10 w-10"
            onClick={onSearchClick}
          >
            <Search className="w-5 h-5" />
          </Button>

          {/* Bookmarks */}
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button
                variant="ghost"
                size="icon"
                className="relative text-slate-600 hover:text-blue-600 hover:bg-blue-50 h-10 w-10"
              >
                <Bookmark className="w-5 h-5" />
                {bookmarks.length > 0 && (
                  <span className="absolute -top-0.5 -right-0.5 w-5 h-5 bg-blue-500 text-white text-[10px] font-bold rounded-full flex items-center justify-center border-2 border-white">
                    {bookmarks.length > 9 ? '9+' : bookmarks.length}
                  </span>
                )}
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent
              align="end"
              className="w-72 bg-white border-slate-200 shadow-lg"
            >
              <div className="px-3 py-2.5 border-b border-slate-100">
                <p className="text-sm font-semibold text-slate-900">Your Bookmarks</p>
                <p className="text-xs text-slate-500 mt-0.5">
                  {bookmarks.length === 0 ? 'No bookmarks yet' : `${bookmarks.length} saved repos`}
                </p>
              </div>
              {bookmarks.length === 0 ? (
                <div className="px-3 py-6 text-center">
                  <Bookmark className="w-10 h-10 text-slate-300 mx-auto mb-2" />
                  <p className="text-sm text-slate-500">Bookmark repos to find them quickly</p>
                </div>
              ) : (
                <div className="max-h-64 overflow-auto">
                  {bookmarks.slice(0, 5).map((bookmark) => (
                    <DropdownMenuItem
                      key={bookmark.id}
                      className="cursor-pointer text-slate-700 hover:bg-blue-50 focus:bg-blue-50 py-2.5"
                      onClick={() => {
                        window.location.hash = `#/repo/${bookmark.full_name}`;
                      }}
                    >
                      <span className="truncate text-sm">{bookmark.full_name}</span>
                    </DropdownMenuItem>
                  ))}
                </div>
              )}
            </DropdownMenuContent>
          </DropdownMenu>

          {/* Notifications */}
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button
                variant="ghost"
                size="icon"
                className="relative text-slate-600 hover:text-blue-600 hover:bg-blue-50 h-10 w-10 hidden sm:flex"
              >
                <Bell className="w-5 h-5" />
                {unread > 0 && (
                  <span className="absolute -top-0.5 -right-0.5 w-5 h-5 bg-red-500 text-white text-[10px] font-bold rounded-full flex items-center justify-center border-2 border-white">
                    {unread > 9 ? '9+' : unread}
                  </span>
                )}
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent
              align="end"
              className="w-80 bg-white border-slate-200 shadow-lg"
            >
              <div className="flex items-center justify-between px-3 py-2.5 border-b border-slate-100">
                <span className="text-sm font-semibold text-slate-900">Notifications</span>
                {unread > 0 && (
                  <button
                    onClick={markAllNotificationsAsRead}
                    className="text-xs text-blue-600 hover:text-blue-700 font-medium"
                  >
                    Mark all read
                  </button>
                )}
              </div>
              <div className="py-8 text-center">
                <Bell className="w-10 h-10 text-slate-300 mx-auto mb-2" />
                <p className="text-sm text-slate-500">No notifications yet</p>
                <p className="text-xs text-slate-400 mt-1">We&apos;ll notify you about updates</p>
              </div>
            </DropdownMenuContent>
          </DropdownMenu>

          {/* Help - Beginner friendly */}
          <Button
            variant="ghost"
            size="icon"
            className="text-slate-600 hover:text-blue-600 hover:bg-blue-50 h-10 w-10 hidden sm:flex"
            onClick={() => alert('Welcome to Repo Store!\n\n🌟 Live Updates: Stats update every 30 seconds\n🔍 Search: Press Cmd+K to search\n💾 Bookmarks: Save repos for later\n📊 Real-time: Watch stars & forks change live')}
          >
            <HelpCircle className="w-5 h-5" />
          </Button>

          {/* User Menu */}
          {isAuthenticated && user ? (
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button
                  variant="ghost"
                  className="h-10 px-2 gap-2 text-slate-600 hover:text-blue-600 hover:bg-blue-50"
                >
                  <img
                    src={user.avatar_url}
                    alt={user.name || user.login}
                    className="w-8 h-8 rounded-full bg-slate-200"
                  />
                  <span className="hidden sm:inline text-sm font-medium">{user.name || user.login}</span>
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent
                align="end"
                className="w-64 bg-white border-slate-200 shadow-lg"
              >
                <div className="px-3 py-3 border-b border-slate-100">
                  <div className="flex items-center gap-3">
                    <img
                      src={user.avatar_url}
                      alt={user.name || user.login}
                      className="w-12 h-12 rounded-full bg-slate-200"
                    />
                    <div>
                      <p className="font-medium text-slate-900">{user.name || user.login}</p>
                      <p className="text-xs text-slate-500">@{user.login}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-4 mt-3 text-sm">
                    <div className="text-center">
                      <p className="font-semibold text-slate-900">{user.public_repos}</p>
                      <p className="text-xs text-slate-500">Repos</p>
                    </div>
                    <div className="text-center">
                      <p className="font-semibold text-slate-900">{user.followers}</p>
                      <p className="text-xs text-slate-500">Followers</p>
                    </div>
                    <div className="text-center">
                      <p className="font-semibold text-slate-900">{user.following}</p>
                      <p className="text-xs text-slate-500">Following</p>
                    </div>
                  </div>
                </div>
                <DropdownMenuItem className="cursor-pointer text-slate-700 hover:bg-blue-50 focus:bg-blue-50 py-2.5">
                  <Github className="w-4 h-4 mr-2.5" />
                  View Profile
                </DropdownMenuItem>
                <DropdownMenuItem className="cursor-pointer text-slate-700 hover:bg-blue-50 focus:bg-blue-50 py-2.5">
                  <Bookmark className="w-4 h-4 mr-2.5" />
                  My Bookmarks ({bookmarks.length})
                </DropdownMenuItem>
                <DropdownMenuSeparator className="bg-slate-100" />
                <DropdownMenuItem 
                  className="cursor-pointer text-red-600 hover:bg-red-50 focus:bg-red-50 py-2.5"
                  onClick={logout}
                >
                  <LogOut className="w-4 h-4 mr-2.5" />
                  Sign Out
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          ) : (
            <Button
              variant="ghost"
              size="sm"
              className="h-10 px-3 gap-2 text-slate-600 hover:text-blue-600 hover:bg-blue-50"
              onClick={handleLogin}
            >
              <Github className="w-4 h-4" />
              <span className="hidden sm:inline text-sm">Sign In</span>
            </Button>
          )}

          {/* Mobile Menu Button */}
          <Button
            variant="ghost"
            size="icon"
            className="md:hidden text-slate-600 hover:text-blue-600 hover:bg-blue-50 h-10 w-10"
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
          >
            {isMobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </Button>
        </div>
      </nav>

      {/* Mobile Menu */}
      {isMobileMenuOpen && (
        <div className="md:hidden bg-white border-t border-slate-100 shadow-lg">
          <div className="px-4 py-3 space-y-1">
            {navLinks.map((link) => (
              <a
                key={link.label}
                href={link.href}
                className="flex items-center gap-3 px-4 py-3 text-sm font-medium text-slate-700 hover:text-blue-600 hover:bg-blue-50 rounded-xl transition-colors"
                onClick={() => setIsMobileMenuOpen(false)}
              >
                <link.icon className="w-5 h-5" />
                {link.label}
              </a>
            ))}
            
            {/* User info in mobile menu */}
            {isAuthenticated && user && (
              <div className="border-t border-slate-100 my-2 pt-2">
                <div className="flex items-center gap-3 px-4 py-3">
                  <img
                    src={user.avatar_url}
                    alt={user.name || user.login}
                    className="w-10 h-10 rounded-full bg-slate-200"
                  />
                  <div>
                    <p className="font-medium text-slate-900">{user.name || user.login}</p>
                    <p className="text-xs text-slate-500">@{user.login}</p>
                  </div>
                </div>
              </div>
            )}
            
            <div className="border-t border-slate-100 my-2 pt-2">
              <button
                onClick={() => {
                  setIsMobileMenuOpen(false);
                  alert('🌟 Live Updates: Stats update every 30 seconds\n🔍 Search: Press Cmd+K to search\n💾 Bookmarks: Save repos for later\n📊 Real-time: Watch stars & forks change live');
                }}
                className="flex items-center gap-3 px-4 py-3 text-sm font-medium text-slate-700 hover:text-blue-600 hover:bg-blue-50 rounded-xl transition-colors w-full"
              >
                <HelpCircle className="w-5 h-5" />
                Help & Tips
              </button>
            </div>
          </div>
        </div>
      )}
    </header>
  );
}
