import { useState, useEffect, useCallback } from 'react';
import { Search, X, Loader2, Clock, TrendingUp, Lightbulb } from 'lucide-react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { searchRepositories, getMockRepositories, formatStarCount } from '@/services/githubApi';
import type { Repository } from '@/types/github';
import { useStore } from '@/hooks/useStore';
import { useRepoContext } from '@/App';

interface SearchDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

const popularSearches = [
  { term: 'react', description: 'UI library' },
  { term: 'nextjs', description: 'React framework' },
  { term: 'tailwindcss', description: 'CSS framework' },
  { term: 'typescript', description: 'Type-safe JS' },
  { term: 'python', description: 'Programming language' },
  { term: 'ai', description: 'AI/ML tools' },
];

const beginnerTips = [
  'Press Enter to search',
  'Click any result to see details',
  'Bookmark repos you like',
];

export function SearchDialog({ open, onOpenChange }: SearchDialogProps) {
  const [query, setQuery] = useState('');
  const [results, setResults] = useState<Repository[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const { searchHistory, addSearchToHistory, clearSearchHistory } = useStore();
  const { setSelectedRepo } = useRepoContext();

  const performSearch = useCallback(async (searchQuery: string) => {
    if (!searchQuery.trim()) {
      setResults([]);
      return;
    }

    setIsLoading(true);
    try {
      const repos = await searchRepositories(searchQuery, 'stars', 'desc', 10);
      if (repos.length === 0) {
        const mockRepos = getMockRepositories().filter(
          (r) =>
            r.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
            r.description?.toLowerCase().includes(searchQuery.toLowerCase()) ||
            r.topics.some((t) => t.toLowerCase().includes(searchQuery.toLowerCase()))
        );
        setResults(mockRepos);
      } else {
        setResults(repos);
      }
    } catch (error) {
      console.error('Search error:', error);
      setResults([]);
    } finally {
      setIsLoading(false);
    }
  }, []);

  useEffect(() => {
    const timeoutId = setTimeout(() => {
      performSearch(query);
    }, 300);

    return () => clearTimeout(timeoutId);
  }, [query, performSearch]);

  const handleSearch = (searchQuery: string) => {
    setQuery(searchQuery);
    if (searchQuery.trim()) {
      addSearchToHistory(searchQuery);
    }
  };

  const handleResultClick = (repo: Repository) => {
    onOpenChange(false);
    setSelectedRepo(repo.full_name);
    window.location.hash = `#/repo/${repo.full_name}`;
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && query.trim()) {
      performSearch(query);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-lg sm:max-w-2xl bg-white border-slate-200 p-0 gap-0 overflow-hidden shadow-2xl">
        <DialogHeader className="p-4 pb-0">
          <DialogTitle className="sr-only">Search Repositories</DialogTitle>
          <div className="relative">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
            <Input
              placeholder="What are you looking for?"
              value={query}
              onChange={(e) => handleSearch(e.target.value)}
              onKeyDown={handleKeyDown}
              className="pl-12 pr-10 h-14 bg-slate-50 border-slate-200 rounded-xl text-slate-900 placeholder:text-slate-400 text-base focus-visible:ring-blue-500"
              autoFocus
            />
            {query && (
              <button
                onClick={() => setQuery('')}
                className="absolute right-4 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 p-1"
              >
                <X className="w-5 h-5" />
              </button>
            )}
          </div>
        </DialogHeader>

        <div className="p-4 max-h-[60vh] overflow-auto">
          {isLoading ? (
            <div className="flex flex-col items-center justify-center py-12">
              <Loader2 className="w-8 h-8 text-blue-500 animate-spin mb-3" />
              <p className="text-sm text-slate-500">Searching repositories...</p>
            </div>
          ) : results.length > 0 ? (
            <div className="space-y-2">
              <p className="text-sm text-slate-500 mb-3">
                Found {results.length} result{results.length !== 1 ? 's' : ''}
              </p>
              {results.map((repo) => (
                <button
                  key={repo.id}
                  onClick={() => handleResultClick(repo)}
                  className="w-full flex items-center gap-4 p-3 rounded-xl hover:bg-blue-50 transition-colors text-left group"
                >
                  <img
                    src={repo.owner.avatar_url}
                    alt={repo.owner.login}
                    className="w-10 h-10 rounded-lg bg-slate-100 flex-shrink-0"
                    loading="lazy"
                  />
                  <div className="flex-1 min-w-0">
                    <p className="font-medium text-slate-900 truncate group-hover:text-blue-600">
                      {repo.full_name}
                    </p>
                    <p className="text-sm text-slate-500 truncate">
                      {repo.description || 'No description available'}
                    </p>
                  </div>
                  <div className="flex items-center gap-1 text-slate-500 flex-shrink-0">
                    <TrendingUp className="w-4 h-4" />
                    <span className="text-sm font-medium">{formatStarCount(repo.stargazers_count)}</span>
                  </div>
                </button>
              ))}
            </div>
          ) : query ? (
            <div className="text-center py-10">
              <div className="w-16 h-16 bg-slate-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Search className="w-8 h-8 text-slate-400" />
              </div>
              <p className="text-slate-600 font-medium mb-1">No results for &quot;{query}&quot;</p>
              <p className="text-sm text-slate-500">Try a different keyword or check your spelling</p>
            </div>
          ) : (
            <div className="space-y-6">
              {/* Beginner Tips */}
              <div className="flex items-start gap-3 p-3 bg-blue-50 rounded-xl">
                <Lightbulb className="w-5 h-5 text-blue-600 flex-shrink-0 mt-0.5" />
                <div>
                  <p className="text-sm font-medium text-blue-900 mb-1">Quick Tips</p>
                  <ul className="text-xs text-blue-700 space-y-1">
                    {beginnerTips.map((tip, i) => (
                      <li key={i}>• {tip}</li>
                    ))}
                  </ul>
                </div>
              </div>

              {/* Search History */}
              {searchHistory.length > 0 && (
                <div>
                  <div className="flex items-center justify-between mb-3">
                    <p className="text-sm font-medium text-slate-700 flex items-center gap-2">
                      <Clock className="w-4 h-4" />
                      Recent Searches
                    </p>
                    <button
                      onClick={clearSearchHistory}
                      className="text-xs text-blue-600 hover:text-blue-700 font-medium"
                    >
                      Clear
                    </button>
                  </div>
                  <div className="flex flex-wrap gap-2">
                    {searchHistory.map((term) => (
                      <button
                        key={term}
                        onClick={() => handleSearch(term)}
                        className="px-3 py-1.5 text-sm bg-slate-100 text-slate-600 rounded-full hover:bg-blue-100 hover:text-blue-700 transition-colors"
                      >
                        {term}
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {/* Popular Searches */}
              <div>
                <p className="text-sm font-medium text-slate-700 mb-3 flex items-center gap-2">
                  <TrendingUp className="w-4 h-4" />
                  Popular Searches
                </p>
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                  {popularSearches.map(({ term, description }) => (
                    <button
                      key={term}
                      onClick={() => handleSearch(term)}
                      className="flex flex-col items-start p-3 bg-slate-50 hover:bg-blue-50 rounded-xl transition-colors text-left group"
                    >
                      <span className="font-medium text-slate-700 group-hover:text-blue-600">{term}</span>
                      <span className="text-xs text-slate-500">{description}</span>
                    </button>
                  ))}
                </div>
              </div>
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}
