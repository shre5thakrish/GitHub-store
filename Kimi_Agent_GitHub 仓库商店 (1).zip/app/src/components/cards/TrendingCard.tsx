import { Star, TrendingUp } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import type { Repository } from '@/types/github';
import { formatStarCount } from '@/services/githubApi';
import { useRepoContext } from '@/App';

interface TrendingCardProps {
  repo: Repository;
  trendingStars?: number;
  rank?: number;
}

export function TrendingCard({ repo, trendingStars, rank }: TrendingCardProps) {
  const { setSelectedRepo } = useRepoContext();

  const handleClick = () => {
    setSelectedRepo(repo.full_name);
    window.location.hash = `#/repo/${repo.full_name}`;
  };

  return (
    <button
      onClick={handleClick}
      className="block w-[260px] sm:w-[280px] flex-shrink-0 p-5 bg-white border border-slate-200 rounded-xl card-hover group snap-start text-left"
    >
      {/* Rank Badge */}
      {rank && (
        <div className="flex items-center justify-between mb-4">
          <div
            className={`w-8 h-8 rounded-lg flex items-center justify-center text-sm font-bold ${
              rank === 1
                ? 'bg-amber-100 text-amber-700'
                : rank === 2
                ? 'bg-slate-200 text-slate-700'
                : rank === 3
                ? 'bg-orange-100 text-orange-700'
                : 'bg-slate-100 text-slate-600'
            }`}
          >
            #{rank}
          </div>
          <TrendingUp className="w-4 h-4 text-blue-600" />
        </div>
      )}

      {/* Owner Avatar & Name */}
      <div className="flex items-center gap-3 mb-4">
        <img
          src={repo.owner.avatar_url}
          alt={repo.owner.login}
          className="w-12 h-12 rounded-xl bg-slate-100"
          loading="lazy"
        />
        <div className="flex-1 min-w-0">
          <h3 className="font-semibold text-slate-900 truncate group-hover:text-blue-600 transition-colors">
            {repo.name}
          </h3>
          <p className="text-sm text-slate-500 truncate">
            by {repo.owner.login}
          </p>
        </div>
      </div>

      {/* Description */}
      {repo.description && (
        <p className="text-sm text-slate-600 mb-4 line-clamp-2">
          {repo.description}
        </p>
      )}

      {/* Stats */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-1.5 text-slate-600">
            <Star className="w-4 h-4 fill-amber-400 text-amber-400" />
            <span className="text-sm font-medium">{formatStarCount(repo.stargazers_count)}</span>
          </div>
          {trendingStars && trendingStars > 0 && (
            <Badge
              variant="secondary"
              className="text-xs bg-green-100 text-green-700 border-none"
            >
              +{formatStarCount(trendingStars)} today
            </Badge>
          )}
        </div>
      </div>

      {/* Language */}
      {repo.language && (
        <div className="mt-3 pt-3 border-t border-slate-100">
          <span className="text-xs text-slate-500">{repo.language}</span>
        </div>
      )}
    </button>
  );
}
