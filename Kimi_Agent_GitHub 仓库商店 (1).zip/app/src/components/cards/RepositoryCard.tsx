import { Star, GitFork, Circle, Bookmark, BookmarkCheck, TrendingUp } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import type { Repository } from '@/types/github';
import { formatStarCount } from '@/services/githubApi';
import { useStore } from '@/hooks/useStore';
import { useRepoContext } from '@/App';
import { useRealtimeRepo, useLiveStats } from '@/hooks/useRealtimeRepos';
import { LiveIndicator, AnimatedNumber, StatChangeIndicator } from '@/components/LiveIndicator';

interface RepositoryCardProps {
  repo: Repository;
  variant?: 'default' | 'compact' | 'featured';
  showDescription?: boolean;
  enableRealtime?: boolean;
}

const languageColors: Record<string, string> = {
  TypeScript: '#3178C6',
  JavaScript: '#F7DF1E',
  Python: '#3776AB',
  Java: '#007396',
  Go: '#00ADD8',
  Rust: '#DEA584',
  'C++': '#F34B7D',
  C: '#555555',
  'C#': '#239120',
  Ruby: '#CC342D',
  PHP: '#4F5D95',
  Swift: '#FFAC45',
  Kotlin: '#A97BFF',
  Dart: '#00B4AB',
  CSS: '#563D7C',
  HTML: '#E34C26',
  Shell: '#89E051',
  Vue: '#4FC08D',
};

export function RepositoryCard({
  repo: initialRepo,
  variant = 'default',
  showDescription = true,
  enableRealtime = true,
}: RepositoryCardProps) {
  const { setSelectedRepo } = useRepoContext();
  const { addBookmark, removeBookmark, isBookmarked } = useStore();
  const bookmarked = isBookmarked(initialRepo.id);
  
  // Real-time updates
  const { repo: realtimeRepo, lastUpdate, refresh, isUpdating } = useRealtimeRepo(
    enableRealtime ? initialRepo : null
  );
  
  const repo = realtimeRepo || initialRepo;
  
  // Animated stats
  const { displayValue: displayStars, isAnimating: starsAnimating } = useLiveStats(
    initialRepo.stargazers_count,
    repo.stargazers_count
  );
  const { displayValue: displayForks, isAnimating: forksAnimating } = useLiveStats(
    initialRepo.forks_count,
    repo.forks_count
  );

  const handleBookmark = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (bookmarked) {
      removeBookmark(repo.id);
    } else {
      addBookmark(repo);
    }
  };

  const handleClick = () => {
    setSelectedRepo(repo.full_name);
    window.location.hash = `#/repo/${repo.full_name}`;
  };

  const languageColor = repo.language ? languageColors[repo.language] || '#64748B' : '#64748B';

  // Calculate trend
  const starDiff = repo.stargazers_count - initialRepo.stargazers_count;
  const isTrending = starDiff > 0;

  if (variant === 'compact') {
    return (
      <button
        onClick={handleClick}
        className="block w-full p-4 bg-white border border-slate-200 rounded-xl card-hover group text-left touch-target"
      >
        <div className="flex items-center gap-3">
          <img
            src={repo.owner.avatar_url}
            alt={repo.owner.login}
            className="w-10 h-10 rounded-lg flex-shrink-0 bg-slate-100"
            loading="lazy"
          />
          <div className="flex-1 min-w-0">
            <h3 className="font-semibold text-slate-900 truncate group-hover:text-blue-600 transition-colors text-sm sm:text-base">
              {repo.name}
            </h3>
            <p className="text-xs sm:text-sm text-slate-500 truncate">
              by {repo.owner.login}
            </p>
          </div>
          <div className="flex items-center gap-1 text-slate-500 flex-shrink-0">
            <Star className="w-4 h-4 fill-amber-400 text-amber-400" />
            <span className="text-sm font-medium">{formatStarCount(repo.stargazers_count)}</span>
          </div>
        </div>
        
        {/* Live indicator */}
        {enableRealtime && (
          <div className="mt-2 flex justify-end">
            <LiveIndicator 
              lastUpdate={lastUpdate} 
              isUpdating={isUpdating} 
              onRefresh={refresh}
              size="sm"
            />
          </div>
        )}
      </button>
    );
  }

  if (variant === 'featured') {
    return (
      <button
        onClick={handleClick}
        className="block w-full p-5 sm:p-6 bg-white border border-slate-200 rounded-2xl card-hover group relative overflow-hidden text-left"
      >
        {/* Live badge */}
        {enableRealtime && isTrending && (
          <div className="absolute top-4 right-4 flex items-center gap-1 px-2 py-1 bg-green-100 text-green-700 text-xs font-medium rounded-full">
            <TrendingUp className="w-3 h-3" />
            +{starDiff}
          </div>
        )}
        
        <div className="relative">
          <div className="flex items-start justify-between mb-4">
            <div className="flex items-center gap-3 sm:gap-4">
              <img
                src={repo.owner.avatar_url}
                alt={repo.owner.login}
                className="w-12 h-12 sm:w-14 sm:h-14 rounded-xl bg-slate-100"
                loading="lazy"
              />
              <div className="min-w-0">
                <h3 className="text-lg sm:text-xl font-bold text-slate-900 group-hover:text-blue-600 transition-colors truncate">
                  {repo.name}
                </h3>
                <p className="text-sm text-slate-500">
                  by {repo.owner.login}
                </p>
              </div>
            </div>
            <Button
              variant="ghost"
              size="icon"
              className="text-slate-400 hover:text-blue-600 hover:bg-blue-50 flex-shrink-0"
              onClick={handleBookmark}
            >
              {bookmarked ? (
                <BookmarkCheck className="w-5 h-5 text-blue-600" />
              ) : (
                <Bookmark className="w-5 h-5" />
              )}
            </Button>
          </div>

          {showDescription && repo.description && (
            <p className="text-slate-600 mb-4 line-clamp-2 text-sm sm:text-base">
              {repo.description}
            </p>
          )}

          <div className="flex flex-wrap items-center gap-3 sm:gap-4 text-sm">
            <div className="flex items-center gap-1.5 text-slate-600" title="Stars">
              <Star className="w-4 h-4 fill-amber-400 text-amber-400" />
              <AnimatedNumber 
                value={displayStars} 
                isAnimating={starsAnimating}
                className="font-medium"
              />
              <StatChangeIndicator 
                previousValue={initialRepo.stargazers_count}
                currentValue={repo.stargazers_count}
              />
            </div>
            <div className="flex items-center gap-1.5 text-slate-600" title="Forks">
              <GitFork className="w-4 h-4 text-slate-400" />
              <AnimatedNumber 
                value={displayForks}
                isAnimating={forksAnimating}
                className="font-medium"
              />
            </div>
            {repo.language && (
              <div className="flex items-center gap-1.5 text-slate-600">
                <Circle className="w-3 h-3" style={{ color: languageColor, fill: languageColor }} />
                <span className="font-medium">{repo.language}</span>
              </div>
            )}
          </div>

          {/* Live indicator */}
          {enableRealtime && (
            <div className="mt-4 pt-3 border-t border-slate-100">
              <LiveIndicator 
                lastUpdate={lastUpdate} 
                isUpdating={isUpdating}
                onRefresh={refresh}
                size="sm"
              />
            </div>
          )}
        </div>
      </button>
    );
  }

  return (
    <button
      onClick={handleClick}
      className="block w-full p-4 sm:p-5 bg-white border border-slate-200 rounded-xl card-hover group text-left"
    >
      <div className="flex items-start justify-between gap-3 mb-3">
        <div className="flex items-center gap-3 min-w-0">
          <img
            src={repo.owner.avatar_url}
            alt={repo.owner.login}
            className="w-9 h-9 sm:w-10 sm:h-10 rounded-lg bg-slate-100 flex-shrink-0"
            loading="lazy"
          />
          <div className="min-w-0">
            <h3 className="font-semibold text-slate-900 group-hover:text-blue-600 transition-colors truncate text-sm sm:text-base">
              {repo.name}
            </h3>
            <p className="text-xs text-slate-500">
              {repo.owner.login}
            </p>
          </div>
        </div>
        <Button
          variant="ghost"
          size="icon"
          className="h-8 w-8 text-slate-400 hover:text-blue-600 hover:bg-blue-50 flex-shrink-0"
          onClick={handleBookmark}
        >
          {bookmarked ? (
            <BookmarkCheck className="w-4 h-4 text-blue-600" />
          ) : (
            <Bookmark className="w-4 h-4" />
          )}
        </Button>
      </div>

      {showDescription && repo.description && (
        <p className="text-sm text-slate-600 mb-3 line-clamp-2">
          {repo.description}
        </p>
      )}

      <div className="flex items-center justify-between flex-wrap gap-2">
        <div className="flex items-center gap-2 sm:gap-3 text-sm">
          <div className="flex items-center gap-1 text-slate-600" title="Stars">
            <Star className="w-4 h-4 fill-amber-400 text-amber-400" />
            <AnimatedNumber 
              value={displayStars}
              isAnimating={starsAnimating}
            />
          </div>
          <div className="flex items-center gap-1 text-slate-600" title="Forks">
            <GitFork className="w-4 h-4 text-slate-400" />
            <AnimatedNumber 
              value={displayForks}
              isAnimating={forksAnimating}
            />
          </div>
        </div>

        <div className="flex items-center gap-2">
          {repo.language && (
            <Badge
              variant="secondary"
              className="text-xs bg-slate-100 text-slate-600 border-none hover:bg-slate-200"
            >
              <Circle
                className="w-2 h-2 mr-1"
                style={{ color: languageColor, fill: languageColor }}
              />
              {repo.language}
            </Badge>
          )}
        </div>
      </div>

      {repo.topics && repo.topics.length > 0 && (
        <div className="flex flex-wrap gap-1.5 mt-3">
          {repo.topics.slice(0, 3).map((topic) => (
            <Badge
              key={topic}
              variant="outline"
              className="text-[10px] sm:text-xs border-slate-200 text-slate-500 hover:border-blue-300 hover:text-blue-600"
            >
              {topic}
            </Badge>
          ))}
        </div>
      )}

      {/* Live indicator */}
      {enableRealtime && (
        <div className="mt-3 pt-3 border-t border-slate-100">
          <LiveIndicator 
            lastUpdate={lastUpdate} 
            isUpdating={isUpdating}
            onRefresh={refresh}
            size="sm"
          />
        </div>
      )}
    </button>
  );
}
