import { Star, ThumbsUp } from 'lucide-react';
import type { Review } from '@/types/github';
import { formatDate } from '@/services/githubApi';

interface ReviewCardProps {
  review: Review;
}

export function ReviewCard({ review }: ReviewCardProps) {
  return (
    <div className="p-4 sm:p-5 bg-white border border-slate-200 rounded-xl hover:border-blue-300 transition-colors">
      {/* Header */}
      <div className="flex items-start justify-between mb-3">
        <div className="flex items-center gap-3">
          <img
            src={review.user.avatar_url}
            alt={review.user.login}
            className="w-10 h-10 rounded-lg bg-slate-100"
            loading="lazy"
          />
          <div>
            <p className="font-medium text-slate-900 text-sm">@{review.user.login}</p>
            <p className="text-xs text-slate-500">
              {formatDate(review.created_at)}
            </p>
          </div>
        </div>

        {/* Rating */}
        <div className="flex items-center gap-0.5">
          {[...Array(5)].map((_, i) => (
            <Star
              key={i}
              className={`w-4 h-4 ${
                i < review.rating
                  ? 'text-amber-400 fill-amber-400'
                  : 'text-slate-200'
              }`}
            />
          ))}
        </div>
      </div>

      {/* Comment */}
      <p className="text-slate-600 text-sm leading-relaxed">
        {review.comment}
      </p>

      {/* Actions */}
      <div className="flex items-center gap-4 mt-4 pt-3 border-t border-slate-100">
        <button className="flex items-center gap-1.5 text-sm text-slate-500 hover:text-blue-600 transition-colors">
          <ThumbsUp className="w-4 h-4" />
          <span>Helpful</span>
        </button>
      </div>
    </div>
  );
}

interface RatingSummaryProps {
  rating: number;
  reviewCount: number;
  distribution?: Record<number, number>;
}

export function RatingSummary({ rating, reviewCount, distribution }: RatingSummaryProps) {
  return (
    <div className="p-5 sm:p-6 bg-white border border-slate-200 rounded-xl">
      <div className="text-center sm:text-left">
        {/* Big Rating */}
        <div className="flex items-center justify-center sm:justify-start gap-4 mb-4">
          <div className="text-5xl font-bold text-slate-900">{rating}</div>
          <div>
            <div className="flex items-center gap-0.5 mb-1">
              {[...Array(5)].map((_, i) => (
                <Star
                  key={i}
                  className={`w-4 h-4 ${
                    i < Math.round(rating)
                      ? 'text-amber-400 fill-amber-400'
                      : 'text-slate-200'
                  }`}
                />
              ))}
            </div>
            <p className="text-sm text-slate-500">
              {reviewCount.toLocaleString()}+ reviews
            </p>
          </div>
        </div>

        {/* Distribution */}
        {distribution && (
          <div className="space-y-1.5">
            {[5, 4, 3, 2, 1].map((star) => {
              const count = distribution[star] || 0;
              const percentage = reviewCount > 0 ? (count / reviewCount) * 100 : 0;
              return (
                <div key={star} className="flex items-center gap-2">
                  <span className="text-xs text-slate-500 w-3">{star}</span>
                  <Star className="w-3 h-3 text-slate-300" />
                  <div className="flex-1 h-2 bg-slate-100 rounded-full overflow-hidden">
                    <div
                      className="h-full bg-amber-400 rounded-full transition-all duration-500"
                      style={{ width: `${percentage}%` }}
                    />
                  </div>
                  <span className="text-xs text-slate-500 w-8 text-right">
                    {Math.round(percentage)}%
                  </span>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}
