import { Globe, Smartphone, Brain, Wrench, Gamepad2, Database, type LucideIcon } from 'lucide-react';
import type { Category } from '@/types/github';

const iconMap: Record<string, LucideIcon> = {
  Globe,
  Smartphone,
  Brain,
  Wrench,
  Gamepad2,
  Database,
};

interface CategoryCardProps {
  category: Category;
  isSelected?: boolean;
  onClick?: () => void;
  repoCount?: number;
}

export function CategoryCard({ category, isSelected = false, onClick, repoCount }: CategoryCardProps) {
  const Icon = iconMap[category.icon] || Globe;

  return (
    <button
      onClick={onClick}
      className={`w-full p-5 sm:p-6 rounded-xl border-2 transition-all duration-200 text-left group ${
        isSelected
          ? 'bg-blue-600 border-blue-600 text-white'
          : 'bg-white border-slate-200 hover:border-blue-300 hover:shadow-md'
      }`}
    >
      <div className="flex items-start justify-between mb-4">
        <div
          className={`w-12 h-12 rounded-xl flex items-center justify-center transition-colors ${
            isSelected ? 'bg-white/20' : 'bg-slate-100 group-hover:bg-blue-50'
          }`}
        >
          <Icon
            className={`w-6 h-6 transition-colors ${
              isSelected ? 'text-white' : 'text-slate-600 group-hover:text-blue-600'
            }`}
          />
        </div>
        {repoCount !== undefined && (
          <span
            className={`text-xs font-medium px-2.5 py-1 rounded-full ${
              isSelected
                ? 'bg-white/20 text-white'
                : 'bg-slate-100 text-slate-600'
            }`}
          >
            {repoCount} repos
          </span>
        )}
      </div>

      <h3
        className={`font-semibold text-lg mb-2 ${
          isSelected ? 'text-white' : 'text-slate-900'
        }`}
      >
        {category.name}
      </h3>

      <p
        className={`text-sm line-clamp-2 ${
          isSelected ? 'text-blue-100' : 'text-slate-500'
        }`}
      >
        {category.description}
      </p>

      <div className={`mt-4 text-sm font-medium ${isSelected ? 'text-white' : 'text-blue-600'}`}>
        Explore →
      </div>
    </button>
  );
}

interface CategoryPillProps {
  category: Category;
  isSelected?: boolean;
  onClick?: () => void;
}

export function CategoryPill({ category, isSelected = false, onClick }: CategoryPillProps) {
  return (
    <button
      onClick={onClick}
      className={`px-4 py-2 rounded-full text-sm font-medium transition-all duration-200 whitespace-nowrap ${
        isSelected
          ? 'bg-blue-600 text-white shadow-sm'
          : 'bg-slate-100 text-slate-600 hover:bg-slate-200 hover:text-slate-900'
      }`}
    >
      {category.name}
    </button>
  );
}
